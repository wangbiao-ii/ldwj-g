class State:
    Master = "Master"
    Backup = "Backup"
    Standalone = "Standalone"
    Fault = "Fault"


class StateStatus:
    BUILDING = "building"
    CANCELING = "canceling"
    SWITCHING = "switching"


class TaskStatus:
    Doing = "Doing"
    Done = "Done"
    Failed = "Failed"


class HATask:
    CANCEL = "cancel"
    BUILD = "build"
    COLD_SYNC = "cold_sync"
    CHECK_CONSISTENCY = 'check_consistency'
    MANUAL_SWITCH = "manual_switch"


class StateOperation:
    BUILD = "build"
    CANCEL = "cancel"
    MANUAL_SWITCH = "manual_switch"


class EndpointType:
    AGENT = 'agent'
    HA = 'ha'
    HEALTH = 'health'
    SYNC = 'sync'
    SYSTEM = 'system'

