from queue import Queue
from haman.common.rpc.client import GRPCClient
from haman.common.struct import State

NotifyQueue = Queue()

KeepAlivedState = State()

PeerClient = GRPCClient()
LocalClient = GRPCClient()
