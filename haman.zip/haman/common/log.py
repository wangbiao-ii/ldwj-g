import logging
from logging import getLogger
from logging.handlers import RotatingFileHandler
from logging.handlers import WatchedFileHandler
from haman.common.utils import Singleton

LOG = logging.getLogger(__name__)


class LogConst:
    LOG_FILE_WATCHED = 0
    LOG_FILE_ROTATING = 1


def exclude_log():
    exclude_list = ['urllib3']
    for logger in exclude_list:
        logging.getLogger(logger).setLevel(logging.INFO)


def init_log(file_path):
    log_manager = DebugLogManager(file_path)
    log_manager.init_root()
    exclude_log()
    LOG.debug("init debug log end.")

    return


class DebugLogManager(Singleton):

    def __init__(self, file_path=None):
        if hasattr(self, "logger") is False:
            self.root_logger = getLogger()

        if hasattr(self, "destination_files") is False:
            self.destination_files = []

        if hasattr(self, "file_path") is False:
            self.file_path = file_path

    def setup_logger(self, logger, file_handler_type, format_t, file_path):

        if file_handler_type == LogConst.LOG_FILE_WATCHED:
            handler = WatchedFileHandler(file_path, encoding='utf-8')
        elif file_handler_type == LogConst.LOG_FILE_ROTATING:
            handler = RotatingFileHandler(file_path, encoding='utf-8')
        else:
            raise Exception("unsupport file handler")

        if file_path in self.destination_files:
            return

        formatter = logging.Formatter(format_t)
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        logger.setLevel(logging.DEBUG)

        self.destination_files.append(file_path)

    def init_root(self):
        format_str = '%(asctime)s [%(threadName)s] %(levelname)-5s %(name)s' + \
                     ' - %(message)s (%(funcName)s:%(lineno)d)'

        self.setup_logger(self.root_logger,
                          LogConst.LOG_FILE_WATCHED,
                          format_str,
                          self.file_path)

    @staticmethod
    def get_logger(name=None):
        return getLogger(name)
