import uuid
import hashlib
import hmac
from datetime import datetime, timedelta
import simplejson
import base64
import logging

LOG = logging.getLogger(__name__)

sign_secret = "xxsdfjsaldfkjlasdf"
time_format = "%Y-%m-%d %H:%M:%S"


def gen_token(username=None):
    token_uuid = str(uuid.uuid4())
    expired_time = datetime.now() + timedelta(minutes=5)
    expired_time_str = expired_time.strftime(time_format)

    data = {
        "uuid": token_uuid,
        "expired": expired_time_str
    }
    if username:
        data['username'] = username
    signature = hmac.new(sign_secret.encode(), simplejson.dumps(data).encode(), hashlib.md5).hexdigest()
    token = {"data": data, "signature": signature}

    token_str = simplejson.dumps(token)
    return base64.b64encode(token_str.encode("utf-8")).decode()


def verify_token(token_str):
    try:
        token_str = base64.b64decode(token_str.encode("utf-8"), validate=True).decode()
    except:
        return False

    token = simplejson.loads(token_str)
    data = token['data']
    signature = hmac.new(sign_secret.encode(), simplejson.dumps(data).encode(), hashlib.md5).hexdigest()

    if signature != token['signature']:
        LOG.error("signature is not correct")
        return False

    expired_time_str = data['expired']
    expired_time = datetime.strptime(expired_time_str, time_format)
    if datetime.now() > expired_time:
        LOG.error("token is expired")
        return False

    return True
