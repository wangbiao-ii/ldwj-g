import logging

LOG = logging.getLogger(__name__)


class HAManException(Exception):
    message = "Unknown error"
    errno = -9999
    lang = 'en'

    def __init__(self, **kwargs):
        self.kwargs = kwargs

    def init_kwargs(self):
        for key, value in self.kwargs.items():
            if isinstance(value, str):
                self.kwargs[key] = str(value.encode('utf-8'))

    def __unicode__(self):
        return str(self.__str__())

    def __str__(self):
        try:
            self.msg = self.message % self.kwargs
        except Exception as e:
            LOG.exception("Exception printable error. Reason: %s" % str(e))
            self.msg = "Exception printable error."

        return self.msg

    def get_errno(self):
        return self.errno

    def get_message(self, lang):
        return str(self)


class InvalidParams(HAManException):
    message = "Invalid RPC param"
    errno = -1000


class RPCResponseError(HAManException):
    message = "RPC response error: %(info)s"
    errno = -1001


class RPCConnectError(HAManException):
    message = "RPC connect error: %(info)s"
    errno = -1002


class ShellCMDExecuteError(HAManException):
    message = "Failed to execute shell command: %(cmd)s, Err: %(err)s"
    errno = -1003
