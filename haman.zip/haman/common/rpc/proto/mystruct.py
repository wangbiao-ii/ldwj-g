from haman.common.rpc.proto.mystruct_pb2 import MyStruct, MyListValue
from google.protobuf.json_format import _WKTJSONMETHODS, SerializeToJsonError, _INT64_TYPES, _FLOAT_TYPES, \
    _NEG_INFINITY, _INFINITY, _NAN, _Printer
import base64
import math

from google.protobuf import descriptor


def set_value(my_value, value):
    if value is None:
        my_value.null_value = 0
    elif isinstance(value, bool):
        my_value.bool_value = value
    elif isinstance(value, str):
        my_value.string_value = value
    elif isinstance(value, float):
        my_value.d_number_value = value
    elif isinstance(value, int):
        my_value.i_number_value = value
    elif isinstance(value, (dict, MyStruct)):
        my_value.struct_value.Clear()
        update_my_struct(my_value.struct_value, value)
    elif isinstance(value, (list, MyListValue)):
        my_value.list_value.Clear()
        extend_my_list(my_value.list_value, value)
    else:
        raise ValueError('Unexpected type %s' % value)


def get_struct_value(struct_value):
    which = struct_value.WhichOneof('kind')
    if which == 'struct_value':
        return struct_value.struct_value
    elif which == 'null_value':
        return None
    elif which == 'i_number_value':
        return struct_value.i_number_value
    elif which == 'd_number_value':
        return struct_value.d_number_value
    elif which == 'string_value':
        return struct_value.string_value
    elif which == 'bool_value':
        return struct_value.bool_value
    elif which == 'list_value':
        return struct_value.list_value
    elif which is None:
        raise ValueError('Value not set')


def update_my_struct(my_struct, value_dict):
    for key, value in value_dict.items():
        set_value(my_struct.fields[key], value)


def extend_my_list(my_list, value_list):
    for value in value_list:
        set_value(my_list.values.add(), value)


class MyPrinter(_Printer):

    def _FieldToJsonObject(self, field, value):
        """Converts field value according to Proto3 JSON Specification."""
        if field.cpp_type == descriptor.FieldDescriptor.CPPTYPE_MESSAGE:
            return self._MessageToJsonObject(value)
        elif field.cpp_type == descriptor.FieldDescriptor.CPPTYPE_ENUM:
            if self.use_integers_for_enums:
                return value
            enum_value = field.enum_type.values_by_number.get(value, None)
            if enum_value is not None:
                return enum_value.name
            else:
                if field.file.syntax == 'proto3':
                    return value
                raise SerializeToJsonError('Enum field contains an integer value '
                                           'which can not mapped to an enum value.')
        elif field.cpp_type == descriptor.FieldDescriptor.CPPTYPE_STRING:
            if field.type == descriptor.FieldDescriptor.TYPE_BYTES:
                # Use base64 Data encoding for bytes
                return base64.b64encode(value).decode('utf-8')
            else:
                return value
        elif field.cpp_type == descriptor.FieldDescriptor.CPPTYPE_BOOL:
            return bool(value)
        elif field.cpp_type in _INT64_TYPES:
            return value
        elif field.cpp_type in _FLOAT_TYPES:
            if math.isinf(value):
                if value < 0.0:
                    return _NEG_INFINITY
                else:
                    return _INFINITY
            if math.isnan(value):
                return _NAN
            if (self.float_format and
                    field.cpp_type == descriptor.FieldDescriptor.CPPTYPE_FLOAT):
                return float(format(value, self.float_format))
        return value


def MyMessageToDict(message,
                    including_default_value_fields=False,
                    preserving_proto_field_name=False,
                    use_integers_for_enums=False,
                    descriptor_pool=None,
                    float_precision=None):
    printer = MyPrinter(
        including_default_value_fields,
        preserving_proto_field_name,
        use_integers_for_enums,
        descriptor_pool,
        float_precision=float_precision)

    return printer._MessageToJsonObject(message)


_WKTJSONMETHODS.update({
    "secaas_lib.rpc.proto.MyStruct": ['_StructMessageToJsonObject',
                                      '_ConvertStructMessage'],
    "secaas_lib.rpc.proto.MyValue": ['_ValueMessageToJsonObject',
                                     '_ConvertValueMessage'],
    "secaas_lib.rpc.proto.MyListValue": ['_ListValueMessageToJsonObject',
                                         '_ConvertListValueMessage']
})
