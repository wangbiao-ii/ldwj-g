import logging
from haman.common.rpc.proto import service_rpc_pb2, service_rpc_pb2_grpc
from haman.common.rpc.proto.mystruct_pb2 import MyValue, MyStruct
from haman.common.rpc.proto.mystruct import MyMessageToDict, update_my_struct, set_value
from haman.common.exception import HAManException, InvalidParams

LOG = logging.getLogger(__name__)


class GRPCServer(service_rpc_pb2_grpc.ServiceRpcServicer):
    def __init__(self, endpoints):
        self.endpoints = endpoints

    def dispatch(self, method, *args, **kwargs):
        for endpoint in self.endpoints:
            if hasattr(endpoint, method):
                func = getattr(endpoint, method)
                result = func(*args, **kwargs)
                return result
        raise Exception("Unsupported RPC method: %s" % method)

    def parse_params(self, request):
        try:
            method = request.method
            args = MyMessageToDict(request.args)
            kwargs = MyMessageToDict(request.kwargs)
            # context = MyMessageToDict(request.context)
            return method, args, kwargs
        except Exception as e:
            raise InvalidParams()

    def common_rpc_call(self, request, context):
        success = True
        total = 0
        result = None
        exception = dict()
        try:
            method, args, kwargs = self.parse_params(request)
            result = self.dispatch(method, *args, **kwargs)
            if isinstance(result, tuple) \
                    and len(result) == 2 \
                    and isinstance(result[0], list) \
                    and isinstance(result[1], int):
                total = result[1]
                result = result[0]
        except HAManException as e:
            LOG.exception("error")
            success = False
            exception = {
                'message': str(e),
                'code': e.get_errno()
            }
        except Exception as e:
            LOG.exception("error")
            success = False
            exception = {
                'message': str(e),
            }

        value_args = MyValue()
        set_value(value_args, result)

        exp_struct = MyStruct()
        update_my_struct(exp_struct, exception)

        return service_rpc_pb2.ServiceRpcResponse(success=success,
                                                  total=total,
                                                  result=value_args,
                                                  exception=exp_struct)
