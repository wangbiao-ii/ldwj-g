import grpc
from haman.common.rpc.proto import service_rpc_pb2, service_rpc_pb2_grpc
from haman.common.rpc.proto.mystruct_pb2 import MyStruct, MyListValue
from haman.common.rpc.proto.mystruct import MyMessageToDict, update_my_struct, extend_my_list
from haman.common.exception import RPCResponseError, RPCConnectError


class GRPCClient(object):

    def __init__(self, address=None):
        self.address = address
        self.channel = None
        self.stub = None

    def reset(self, address):
        self.close()
        self.address = address
        self.channel = grpc.insecure_channel(self.address)
        self.stub = service_rpc_pb2_grpc.ServiceRpcStub(self.channel)

    def close(self):
        if self.channel:
            self.channel.close()

    def call(self, method, *args, **kwargs):
        caller = self.get_caller()
        return caller(method, *args, **kwargs)

    def get_caller(self, timeout=None):
        if not self.address:
            raise Exception("Cannot remote call without address")

        if not self.channel:
            self.channel = grpc.insecure_channel(self.address)
            self.stub = service_rpc_pb2_grpc.ServiceRpcStub(self.channel)

        return Caller(self.stub, timeout)


class Caller(object):

    def __init__(self, stub, timeout):
        self.stub = stub
        self.timeout = timeout

    def __call__(self, method, *args, **kwargs):

        list_value_args = MyListValue()
        extend_my_list(list_value_args, list(args))
        struct_kwargs = MyStruct()
        update_my_struct(struct_kwargs, kwargs)

        request = service_rpc_pb2.ServiceRpcRequest(
            method=method,
            args=list_value_args,
            kwargs=struct_kwargs
        )
        try:
            response = self.stub.common_rpc_call(request, timeout=self.timeout)
        except Exception as e:
            raise RPCConnectError(info=str(e))

        if response.success:
            return MyMessageToDict(response.result)
        else:
            exception = MyMessageToDict(response.exception)
            e = RPCResponseError(info=exception['message'])
            e.errno = exception.get('code') or 999
            raise e
