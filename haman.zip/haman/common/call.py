class HAManCall(object):

    def __call__(self, *args, **kwargs):
        pass
