import yaml
import haman
import os

DEFAULT_SETTINGS = {
    "max_workers": 3,
    "listen_host": "0.0.0.0",
    "listen_port": "8888",
    "log_file": "/var/log/haman.log",
    "data_path": "/var/lib/haman/"
}


class HAManCfg(object):

    def __init__(self):
        self.config_dict = None
        self.resource_order = []

    def get_cfg_path(self):
        return os.path.abspath(os.path.dirname(haman.__file__)) + "/haman.yaml"

    @staticmethod
    def megre_default_setting(setting_dir):
        setting_copy = DEFAULT_SETTINGS.copy()
        setting_copy.update(setting_dir)
        return setting_copy

    def load(self):
        with open(self.get_cfg_path(), "r") as f:
            content = f.read()
        self.config_dict = yaml.load(content, Loader=yaml.FullLoader)
        self.config_dict['settings'] = self.megre_default_setting(self.config_dict.get("settings", {}))
        self._order_resource()

    def _order_resource(self):
        resource_order = []
        remain_resources = self.resources.copy()

        while remain_resources:
            dead = True
            check_list = list(remain_resources.keys())
            for resource_name in check_list:
                resource_info = remain_resources[resource_name]
                depends = resource_info.get('depends', [])
                for depend in depends:
                    if depend not in resource_order:
                        break
                else:
                    resource_order.append(resource_name)
                    remain_resources.pop(resource_name)
                    dead = False

            if dead:
                raise Exception("Depends of resources are not correct.")

        self.resource_order = resource_order

    @property
    def resources(self):
        return self.config_dict.get("resources", {})

    def get_resource(self, resource_name):
        return self.resources.get(resource_name, {})

    @property
    def settings(self):
        return self.config_dict.get("settings", {})

    @property
    def listen_host(self):
        return self.settings['listen_host']

    @property
    def listen_port(self):
        return self.settings['listen_port']

    @property
    def listen_address(self):
        return self.listen_host + ":" + str(self.listen_port)

    @property
    def log_file(self):
        return self.settings['log_file']

    @property
    def data_path(self):
        return self.settings['data_path']

    @property
    def max_workers(self):
        return self.settings['max_workers']

    @property
    def params_path(self):
        return self.data_path + "/params.json"

    @property
    def state_path(self):
        return self.data_path + "/state.json"


CONF = HAManCfg()
