from haman.common.config import CONF
import haman.common.constance as cons
import os
import time
import simplejson
import logging

LOG = logging.getLogger(__name__)


class State(object):

    def __init__(self, params=None):
        self.info = params or {}
        self.status = None

    def __str__(self):
        return str(self.info)

    def __repr__(self):
        return self.__str__()

    def load(self):
        state_path = CONF.state_path
        if os.path.exists(state_path):
            with open(state_path, 'r') as file:
                content = file.read()
            self.info = simplejson.loads(content)
        else:
            self.info = {
                'state': cons.State.Standalone
            }
        LOG.debug("load state: %s" % self.value)

    def update_state(self, state, write=False):
        self.info['state'] = state
        self.status = None
        if write:
            self.write()

    def write(self):
        state_path = CONF.state_path
        with open(state_path, 'w') as file:
            file.write(simplejson.dumps(self.info))

    @property
    def value(self):
        return self.info.get('state')


class Notify(object):

    def __init__(self, state):
        self.state = state
        self.time = time.time()
