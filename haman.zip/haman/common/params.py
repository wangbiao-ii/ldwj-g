from haman.common.config import CONF
from haman.common.global_value import PeerClient
import os
import simplejson
import logging

LOG = logging.getLogger(__name__)


class Params(object):

    def __init__(self, info=None):
        self.info = info or {}
        if info:
            self.setup_peer_client()

    def load(self):
        params_path = CONF.params_path
        if os.path.exists(params_path):
            with open(params_path, 'r') as file:
                content = file.read()
            self.info = simplejson.loads(content)
            self.setup_peer_client()

    def add_peer_network_info(self, peer_network):
        self.info['peer_network'] = peer_network

    def setup_peer_client(self):
        PeerClient.reset(self.peer_ctl_interface_ip + ":" + str(CONF.listen_port))

    def update(self, info):
        self.info = info

    def write(self):
        params_path = CONF.params_path
        with open(params_path, 'w') as file:
            file.write(simplejson.dumps(self.info))

    def __str__(self):
        return str(self.info)

    def __repr__(self):
        return self.__str__()

    # @property
    # def peer_ip(self):
    #     return self.info.get('peer_ip')

    @property
    def vip_list(self):
        return self.info.get('vip_list', [])

    @property
    def data_interface(self):
        return self.data_interface_info['interface']

    @property
    def local_data_interface_ip(self):
        return self.data_interface_info['local_ip']

    @property
    def peer_data_interface_ip(self):
        return self.data_interface_info['peer_ip']

    @property
    def data_interface_info(self):
        return self.info.get('data_interface', {})

    @property
    def ctl_interface(self):
        return self.ctl_interface_info.get('interface')

    @property
    def local_ctl_interface_ip(self):
        return self.ctl_interface_info['local_ip']

    @property
    def peer_ctl_interface_ip(self):
        return self.ctl_interface_info['peer_ip']

    @property
    def ctl_interface_info(self):
        return self.info.get('ctl_interface')

    @property
    def preempt(self):
        return self.info.get('preempt', True)

    @property
    def master(self):
        return self.info.get('master', False)

    @property
    def group_id(self):
        return self.info.get('group_id')

    @property
    def hello_interval(self):
        return self.info.get('hello_interval', 3)

