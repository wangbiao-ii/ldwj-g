import subprocess
import haman.common.exception as exp
import sys
import traceback
from functools import wraps
from threading import Thread, RLock
import logging

LOG = logging.getLogger(__name__)


class _Singleton(object):
    _instance = None

    def __new__(class_, *args, **kwargs):
        if not isinstance(class_._instance, class_):
            class_._instance = object.__new__(class_)
        return class_._instance


class Singleton(_Singleton):
    initialized = False

    @classmethod
    def already_initialized(cls):
        return cls.initialized

    @classmethod
    def finish_initialized(cls):
        cls.initialized = True


class HamanLock(object):

    def __init__(self, name, debug=True, lock=RLock):
        self.name = name
        self.lock = lock()
        self.debug = debug

    def log(self, msg):
        if not self.debug:
            return
        LOG.debug(msg)

    def acquire(self, blocking=True, timeout=-1):
        self.log("try to lock %s, %s" % (self.name, self.lock))
        result = self.lock.acquire(blocking, timeout)
        self.log("%s, %s locked" % (self.name, self.lock))
        return result

    def release(self):
        self.log("release lock %s, %s" % (self.name, self.lock))
        result = self.lock.release()
        self.log("lock %s, %s released" % (self.name, self.lock))
        return result


def lockhelper(lock):
    def _deco(func):
        def __deco(*args, **kwargs):
            ret = None
            LOG.debug("acquire lock %s" % lock)
            if lock.acquire():
                try:
                    ret = func(*args, **kwargs)
                except Exception as e:
                    LOG.exception('lockhelper')
                    lock.release()
                    raise e
                lock.release()
                LOG.debug("release lock %s" % lock)
            return ret

        return __deco

    return _deco


def bash(cmd, ignore_error=False):
    output = ""
    if not isinstance(cmd, list):
        cmd = [cmd]

    for _cmd in cmd:
        ret, _output = subprocess.getstatusoutput(_cmd)
        if ret != 0 and not ignore_error:
            raise exp.ShellCMDExecuteError(cmd=cmd, err=_output)
        output += _output

    return output


def get_nic_address(device):
    return bash("ip a show %s | grep \"inet \" | awk -F ' ' '{print $2}' | head -1" % device)


def get_all_nics_address():
    output = bash("ip a | grep -E '^[1-9]' | awk -F ': ' '{print $2}' | grep -v lo")
    nics = output.split('\n')
    result = {}
    for nic in nics:
        ip = get_nic_address(nic)
        result[nic] = ip

    return result


def do_in_thread():
    def _inner_(fn):
        @wraps(fn)
        def _wraps_(*args, **kwargs):
            t = Thread(target=fn, args=args, kwargs=kwargs)
            t.setDaemon(True)
            t.start()
            return t

        return _wraps_

    return _inner_


def import_class(import_str):
    """Returns a class from a string including module and class.
    .. versionadded:: 0.3
    """
    mod_str, _sep, class_str = import_str.rpartition('.')
    __import__(mod_str)
    try:
        return getattr(sys.modules[mod_str], class_str)
    except AttributeError:
        raise ImportError('Class %s cannot be found (%s)' %
                          (class_str,
                           traceback.format_exception(*sys.exc_info())))
