from haman.common.rpc.client import GRPCClient
from haman.common.constance import State, TaskStatus
import logging
from datetime import timedelta, datetime
import time

LOG = logging.getLogger(__name__)


class HAManAPI(object):

    def __init__(self, grpc_client: GRPCClient):
        self.client = grpc_client
        self.state_cache = None
        self.cache_expired = None

    def call(self, method, *args, **kwargs):
        return self.get_caller(timeout=30)(method, *args, **kwargs)

    def get_caller(self, timeout=None):
        return self.client.get_caller(timeout)

    def is_in_ha(self):
        state = self.get_ha_state()
        if state != State.Standalone:
            return True
        return False

    def get_task_status(self):
        return self.call("get_task_status")

    def wait_ha_task(self, task_name=None, interval=3, timeout=3600):
        retry = timeout / interval
        while retry:
            result = self.get_task_status()
            if task_name:
                if result['task'] != task_name:
                    LOG.debug("Not same task...")
                    return {}

            status = result['status']
            if status == TaskStatus.Done:
                LOG.debug("HA task done")
                return result.get('result')
            elif status == TaskStatus.Doing:
                pass
            else:
                LOG.error("HA task failed")
                raise Exception("HA task failed")

            time.sleep(interval)
            retry -= 1
        else:
            raise Exception("wait HA task timeout")

    def build_ha(self, vip_list, ctl_interface, data_interface, preempt, group_id, hello_interval, master=True):
        return self.call("build_ha", vip_list, ctl_interface, data_interface, preempt, group_id, hello_interval, master)

    def cancel_ha(self, include_peer=True):
        return self.call("cancel_ha", include_peer)

    def show_ha(self):
        return self.call("show_ha")

    def get_ha_state(self):
        state = self.call("get_ha_state")
        if state != self.state_cache:
            now_time = datetime.now()
            self.update_state_cache(state, now_time)
        return state

    def update_state_cache(self, state, now_time):
        # LOG.debug("update state cache: %s" % state)
        self.state_cache = state
        self.cache_expired = now_time + timedelta(seconds=30)

    def get_state_cache(self):
        now_time = datetime.now()
        if not self.state_cache or not self.cache_expired or now_time > self.cache_expired:
            state = self.get_ha_state()
            self.update_state_cache(state, now_time)

        return self.state_cache

    def switch_ha(self):
        return self.call("switch_ha")

    def notify(self, state):
        caller = self.get_caller(timeout=3)
        return caller("notify", state)

    def remote_agent_call(self, resource_name, method_name, *args, **kwargs):
        caller = self.get_caller(timeout=3600)
        return caller("remote_agent_call", resource_name, method_name, *args, **kwargs)

    def is_health(self):
        caller = self.get_caller(timeout=3)
        return caller("is_health")

    def get_last_health_result(self):
        caller = self.get_caller(timeout=3)
        return caller("get_last_health_result")

    def cold_sync(self):
        return self.call("cold_sync")

    def check_consistent(self):
        return self.call("check_consistent")

    def get_networks(self):
        return self.call("get_networks")

    def log(self, msg):
        return self.call("log", msg)

    def follow_task(self, task_name, data=None):
        return self.call("follow_task", task_name, data)

    def close(self):
        if self.client:
            self.client.close()
