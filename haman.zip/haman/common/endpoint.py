class BaseEndpoint(object):
    pass


class RPCEndpoint(BaseEndpoint):
    pass
