#!/bin/python3

from haman.common.rpc.client import GRPCClient
from haman.common.api import HAManAPI
from haman.common.config import CONF
import simplejson
import sys

if __name__ == '__main__':
    CONF.load()
    with open(CONF.state_path, 'w') as file:
        state = {
            "state": sys.argv[1]
        }
        file.write(simplejson.dumps(state))

    client = GRPCClient(CONF.listen_address)
    HAManAPI(client).notify(sys.argv[1])

    client.close()
