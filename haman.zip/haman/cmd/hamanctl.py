#!/bin/python3

import argparse
from haman.common.rpc.client import GRPCClient
from haman.common.api import HAManAPI
from haman.common.constance import TaskStatus
from haman import VERSION
from haman.common.config import CONF
import sys
import time


class HAManCtl(object):

    def __init__(self):
        CONF.load()
        self.client = GRPCClient(CONF.listen_address)
        self.api = HAManAPI(self.client)
        self.parser = None
        self.setup_argparse()

    def wait_task(self):
        retry = 600
        while retry:
            result = self.get_task_status()
            status = result['status']
            if status == TaskStatus.Done:
                print("task finish")
                return result.get('result')
            elif status == TaskStatus.Doing:
                print(".", end="")
            else:
                print("task failed")
                raise Exception("task failed")

            time.sleep(3)
            retry -= 1
        else:
            raise Exception("failed to create ha")

    def get_task_status(self):
        return self.client.call("get_task_status")

    # def build_ha(self, **kwargs):
    #     self.api.build_ha(
    #         peer_ip="10.182.52.163",
    #         vip_list=[{"ip": "10.182.52.135/24", "dev": "eth0"}],
    #         ctl_interface="eth1",
    #         data_interface="eth2",
    #         preempt=False,
    #         group_id=1,
    #         master=True
    #     )
    #     self.wait_task()

    def cancel_ha(self):
        self.api.cancel_ha(include_peer=True)
        self.wait_task()

    def show_state(self):
        print(self.api.get_ha_state())

    def cold_sync(self):
        self.api.cold_sync()
        self.wait_task()

    def check_consistent(self):
        self.api.check_consistent()
        print(self.wait_task())

    def switch(self):
        self.api.switch_ha()
        self.wait_task()

    def notify(self):
        self.api.notify("Master")

    def show_state(self):
        print(self.api.get_ha_state())

    def setup_argparse(self):
        self.parser = argparse.ArgumentParser()
        self.parser.add_argument(
            '--version',
            action='version',
            version=VERSION
        )

        subparser = self.parser.add_subparsers(title='subcommands', dest="subcommand")
        # build_ha_parser = subparser.add_parser('build-ha', help="build ha")
        cancel_ha_parser = subparser.add_parser('cancel-ha', help="cancel ha")
        show_ha_state_parser = subparser.add_parser('show-state', help="show ha state")
        cold_sync_parser = subparser.add_parser('cold-sync', help="cold sync")
        show_sync_parser = subparser.add_parser('check-consistent', help="check consistent")
        # show_task_parser = subparser.add_parser('task-status', help="show task status")
        # show_state_parser = subparser.add_parser('state', help="show state status")
        switch_parser = subparser.add_parser("switch", help="manual switch between master and backup")
        notify_parser = subparser.add_parser("notify", help="manual switch between master and backup")

    def do_action(self):
        parsed_args = self.parser.parse_args(sys.argv[1:])
        opt = vars(parsed_args)
        subcommand = opt.pop('subcommand')
        subcommand = subcommand.replace("-", "_")
        handler = getattr(self, subcommand)
        handler(**opt)


def main():
    ctl = HAManCtl()
    ctl.do_action()
    ctl.client.close()


if __name__ == '__main__':
    main()
