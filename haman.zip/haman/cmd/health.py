#!/bin/python3

from haman.common.rpc.client import GRPCClient
from haman.common.api import HAManAPI
from haman.common.config import CONF
import sys

if __name__ == '__main__':
    CONF.load()
    client = GRPCClient(CONF.listen_address)
    try:
        result = HAManAPI(client).is_health()
        if not result:
            sys.exit(1)
    except:
        sys.exit(1)
    finally:
        client.close()
