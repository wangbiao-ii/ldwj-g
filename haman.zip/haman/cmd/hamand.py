from haman.common.rpc.proto import service_rpc_pb2_grpc
from haman.common.rpc.server import GRPCServer
from haman.service.state import StateManager
from haman.common.global_value import LocalClient
from haman.api import ENDPOINTS
from haman.common.config import CONF
from haman.common.log import init_log
from haman.common.utils import bash
from concurrent import futures
import grpc
import logging
import time

LOG = logging.getLogger(__name__)


class HAMan(object):

    def __init__(self):
        self.grpc_server = None

    def setup_grpc(self):
        grpc_server = grpc.server(futures.ThreadPoolExecutor(max_workers=CONF.max_workers))
        service_rpc_pb2_grpc.add_ServiceRpcServicer_to_server(GRPCServer(ENDPOINTS), grpc_server)
        grpc_server.add_insecure_port(CONF.listen_address)
        self.grpc_server = grpc_server
        self.grpc_server.start()

    @staticmethod
    def read_config():
        CONF.load()
        LocalClient.address = CONF.listen_address

    def handle_grpc(self):
        self.grpc_server.wait_for_termination()

    def init_log(self):
        init_log(CONF.log_file)

    def load_data(self):
        bash("mkdir -p %s" % CONF.data_path)
        StateManager().load()

    def log_launch(self):
        LOG.debug("load configs: %s" % CONF.config_dict)

    def launch(self):
        self.read_config()
        self.setup_grpc()
        self.init_log()
        self.log_launch()
        self.load_data()
        self.handle_grpc()


def main():
    try:
        hamand = HAMan()
        hamand.launch()
    except Exception as e:
        LOG.exception("Failed to launch haman.")
        raise e


if __name__ == '__main__':
    main()
