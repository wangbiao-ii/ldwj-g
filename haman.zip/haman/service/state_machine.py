from haman.common.constance import State, StateOperation
from haman.common.utils import HamanLock
from threading import Lock
import logging

LOG = logging.getLogger(__name__)

OPERATION_RULE = {
    State.Backup: [StateOperation.CANCEL, StateOperation.BUILD],
    State.Master: [StateOperation.CANCEL, StateOperation.MANUAL_SWITCH, StateOperation.BUILD],
    State.Standalone: [StateOperation.BUILD]
}


class StateMachine(object):

    def __init__(self):
        self.pre_state = None
        self.cur_state = None
        self.next_state = None
        self.state_changing = False

        self.operation = None
        self.operation_lock = {
            StateOperation.BUILD: HamanLock(StateOperation.BUILD, lock=Lock),
            StateOperation.CANCEL: HamanLock(StateOperation.CANCEL, lock=Lock),
            StateOperation.MANUAL_SWITCH: HamanLock(StateOperation.MANUAL_SWITCH, lock=Lock)
        }

    def is_allow_operation(self, operation):
        if self.operation:
            LOG.debug("There is operation %s in doing" % self.operation)
            return False

        if operation in OPERATION_RULE[self.cur_state]:
            return True

        LOG.debug("Operation %s not allowed in state %s" % (operation, self.cur_state))
        return False

    def is_in_operation(self, operation):
        return self.operation == operation

    def set_operation_doing(self, operation):
        get_lock = self.operation_lock[operation].acquire(blocking=False)
        if not get_lock:
            raise Exception("operation %s is already in doing" % operation)

        LOG.debug("Set operation %s in doing" % operation)
        self.operation = operation

    def finish_operation(self, operation):
        try:
            self.operation_lock[operation].release()
        except:
            LOG.error("Failed to finish operation %s" % self.operation)

        if self.operation == operation:
            self.operation = None

    def wait_operation_finish(self, operation, timeout=300):
        LOG.debug("wait operation %s finish..." % operation)
        success = self.operation_lock[operation].acquire(blocking=True, timeout=timeout)
        if not success:
            LOG.error("wait operation %s finish timeout" % operation)
        self.finish_operation(operation)
        return success

    def set_next_state(self, state):
        self.state_changing = True
        self.next_state = state

    def set_cur_state(self, state):
        LOG.debug("Update state machine to state: %s" % state)
        self.pre_state = self.cur_state
        self.cur_state = state
        self.state_changing = False

        if self.operation:
            self.finish_operation(self.operation)


HAMAN_STATE_MACHINE = StateMachine()
