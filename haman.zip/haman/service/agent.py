from haman.common.utils import Singleton, import_class
from haman.common.config import CONF
import logging

LOG = logging.getLogger(__name__)


class AgentManager(Singleton):

    def __init__(self):
        if self.already_initialized():
            return
        self.agents = {}
        self.finish_initialized()

    def update_agent_params(self, params):
        for agent_name, agent in self.agents.items():
            agent.update_params(params)

    def setup_agents(self, state, params):
        LOG.debug("Start to setup agent by %s" % state)

        for resource_name in CONF.resource_order:
            try:
                resource_info = CONF.get_resource(resource_name)

                agent_cls = import_class("haman.resource.%s.agent.Agent" % resource_name)
                config_cls = import_class("haman.resource.%s.config.Config" % resource_name)
                agent_cls.name = config_cls.name

                resource_config = config_cls(
                    configs=resource_info.get("configs"),
                    params=params
                )

                resource_agent = agent_cls(
                    resource_config=resource_config,
                    launch_state=state
                )

                self.agents[resource_name] = resource_agent
            except:
                LOG.exception("Failed to setup agent %s" % resource_name)

            LOG.debug("Agent %s setup success." % resource_name)

    def get_agent(self, resource_name):
        return self.agents.get(resource_name)
