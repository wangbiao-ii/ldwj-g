from copy import deepcopy

from haman.common.utils import Singleton, do_in_thread, get_nic_address, bash
import haman.common.constance as cons
from haman.service.state import StateManager
from haman.service.state_machine import HAMAN_STATE_MACHINE
from haman.common.config import CONF
from haman.common.api import HAManAPI
from haman.common.params import Params
from haman.common.struct import Notify
from haman.service.agent import AgentManager
from haman.common.global_value import PeerClient, NotifyQueue
from haman.resource.keepalived.service import KeepAlivedService
from threading import RLock
import logging
import time

LOG = logging.getLogger(__name__)


class HATask(object):
    name = None
    need_lock = False
    operation = None

    def __init__(self, data=None, follow=False):
        self.data = data
        self.follow = follow
        self.peer = HAManAPI(PeerClient)

    @staticmethod
    def setup_peer_client(data):
        PeerClient.reset(data['ctl_interface']['peer_ip'] + ":" + str(CONF.listen_port))

    @classmethod
    def notify(cls, state):
        NotifyQueue.put(Notify(state))

    def get_result(self):
        return {}

    def check_permission(self):
        pass

    def do_action(self):
        pass

    def start_operation(self):
        if self.operation:
            if HAMAN_STATE_MACHINE.is_allow_operation(self.operation):
                HAMAN_STATE_MACHINE.set_operation_doing(self.operation)
            else:
                raise Exception("operation %s is not allowed in current state" % self.operation)

    def wait_operation(self):
        if self.operation:
            success = HAMAN_STATE_MACHINE.wait_operation_finish(self.operation)
            if not success:
                raise Exception("Failed to do operation %s" % self.operation)

    def end_operation(self):
        if self.operation:
            HAMAN_STATE_MACHINE.finish_operation(self.operation)

    def error_action(self):
        pass

    def start(self):
        self.start_operation()

        LOG.debug("start to execute task %s" % self.name)

        try:
            self.do_action()
        except Exception as e:
            self.error_action()
            self.end_operation()
            LOG.debug("failed to execute task %s" % self.name)
            raise e

        try:
            self.wait_operation()
        except Exception as e:
            self.error_action()
            LOG.debug("failed to wait task %s operation" % self.name)
            raise e

        LOG.debug("finish to execute task %s" % self.name)


class BuildHATask(HATask):
    name = cons.HATask.BUILD
    operation = cons.StateOperation.BUILD
    need_lock = True

    # @staticmethod
    # def gen_params(data, peer_networks):
    #     # 替换对端IP为控制口的IP
    #     ctl_interface = data['ctl_interface']['']
    #     data['peer_ip'] = peer_networks[ctl_interface].split('/')[0]
    #
    #     params = Params(data)
    #     params.add_peer_network_info(peer_networks)
    #     return params

    def prepare_to_build_ha(self, data):
        params = Params(data)
        StateManager().update_params(params)

    def tell_peer_to_build_ha(self, data):
        peer_data = deepcopy(data)
        peer_data['ctl_interface']['peer_ip'] = data['ctl_interface']['local_ip']
        peer_data['ctl_interface']['local_ip'] = data['ctl_interface']['peer_ip']
        peer_data['data_interface']['peer_ip'] = data['data_interface']['local_ip']
        peer_data['data_interface']['local_ip'] = data['data_interface']['peer_ip']
        peer_data['master'] = False
        self.peer.follow_task(self.name, peer_data)

    def build_ha_by_agents(self):
        self.peer.log("build ha by agents started from peer")
        for resource_name in AgentManager().agents.keys():
            agent = AgentManager().get_agent(resource_name)
            LOG.debug("create master for %s" % agent.name)
            agent.build(cons.State.Master)
            LOG.debug("create backup in peer for %s" % agent.name)
            self.peer.remote_agent_call(resource_name, "build", cons.State.Backup)
        self.peer.log("build ha by agents from peer finished")

    def do_action(self):
        LOG.debug("Start to build HA")

        self.setup_peer_client(self.data)

        if not self.follow:
            self.tell_peer_to_build_ha(self.data)

        self.prepare_to_build_ha(self.data)

        if self.follow:
            # stop, otherwise when master build agent(restart keepalived), slave switch to master
            LOG.debug("backup stop keepalived")
            agent = AgentManager().get_agent(KeepAlivedService.name)
            agent.stop_monitor_task()
            KeepAlivedService.stop()
            return

        try:
            self.build_ha_by_agents()
        except Exception as e:
            LOG.exception("Failed to build ha by agents")
            raise Exception("Failed to build HA")

    def wait_peer_to_backup(self):
        retry = 60
        while retry:
            LOG.debug("wait peer change state")
            peer_state = self.peer.get_ha_state()
            LOG.debug("get peer %s" % peer_state)
            if peer_state != cons.State.Standalone:
                break
            time.sleep(3)
            retry -= 1
        else:
            raise Exception("wait peer timeout")

    def wait_operation(self):
        if not self.follow:
            # wait local finished
            LOG.debug("get local %s" % HAMAN_STATE_MACHINE.cur_state)
            super(BuildHATask, self).wait_operation()
            LOG.debug("get local %s" % HAMAN_STATE_MACHINE.cur_state)
            # wait peer follow finished
            self.wait_peer_to_backup()
        else:
            self.end_operation()


class CancelHATask(HATask):
    name = cons.HATask.CANCEL
    operation = cons.StateOperation.CANCEL
    need_lock = True

    def check_permission(self):
        if not self.follow and HAMAN_STATE_MACHINE.cur_state == cons.State.Backup:
            raise Exception("Cannot cancel peer when device in backup state")

    @classmethod
    def build_standalone(cls):
        agents = AgentManager().agents.values()
        for agent in list(agents)[::-1]:
            try:
                LOG.debug("build standalone for %s" % agent.name)
                agent.build_standalone()
            except:
                LOG.exception("failed to restore stanalone for %s" % agent.name)

        bash("rm -rf %s" % CONF.params_path)
        bash("rm -rf %s" % CONF.state_path)
        cls.notify(cons.State.Standalone)

    def cancel_peer_ha(self):
        try:
            self.peer.follow_task(self.name)
        except Exception as e:
            LOG.exception("warning: failed to cancel peer")

    def do_action(self):
        LOG.debug("start to cancel ha")
        if not self.follow:
            self.cancel_peer_ha()

        self.build_standalone()


class ManualSwitchTask(HATask):
    name = cons.HATask.MANUAL_SWITCH
    operation = cons.StateOperation.MANUAL_SWITCH
    need_lock = True

    def wait_peer_to_master(self):
        retry = 20
        while retry:
            LOG.debug("wait peer change master")
            peer_state = self.peer.get_ha_state()
            LOG.debug("get peer %s" % peer_state)
            if peer_state == cons.State.Master:
                break
            time.sleep(1)
            retry -= 1
        else:
            raise Exception("wait peer timeout")

    def do_action(self):
        LOG.debug("Start to do manual switch")
        keepalived_agent = AgentManager().get_agent('keepalived')
        keepalived_agent.manual_switch()

    def error_action(self):
        LOG.debug("Failed to manual switch, try to restore priority")
        keepalived_agent = AgentManager().get_agent('keepalived')
        keepalived_agent.try_to_restore_priority()

    def wait_operation(self):
        super(ManualSwitchTask, self).wait_operation()
        # self.wait_peer_to_master()


class ColdSyncTask(HATask):
    name = cons.HATask.COLD_SYNC
    need_lock = True

    def check_permission(self):
        if HAMAN_STATE_MACHINE.cur_state != cons.State.Master:
            raise Exception("Cannot only run cold sync in master")

    def do_action(self):
        self.peer.log("cold sync started from peer")
        agents = AgentManager().agents.values()
        for agent in agents:
            LOG.debug("sync for %s" % agent.name)
            agent.sync()
        self.peer.log("cold sync from peer finished")

        self.peer.remote_agent_call('keepalived', 'manual_launch')


class CheckConsistentTask(HATask):
    name = cons.HATask.CHECK_CONSISTENCY
    consistent_result = {}

    def check_permission(self):
        if HAMAN_STATE_MACHINE.cur_state != cons.State.Master:
            raise Exception("Cannot only run check consistent in master")

    def do_action(self):
        agents = AgentManager().agents.values()
        self.consistent_result = {}
        for agent in agents:
            LOG.debug('check consistency for %s' % agent.name)
            if not agent.is_consistent():
                LOG.error("agent %s is not consistency" % agent.name)
                self.consistent_result[agent.name] = False
            else:
                LOG.debug('agent %s is consistency' % agent.name)
                self.consistent_result[agent.name] = True

    def get_result(self):
        return self.consistent_result


def get_task_cls(task_name):
    task_map = {
        cons.HATask.BUILD: BuildHATask,
        cons.HATask.CANCEL: CancelHATask,
        cons.HATask.COLD_SYNC: ColdSyncTask,
        cons.HATask.MANUAL_SWITCH: ManualSwitchTask,
        cons.HATask.CHECK_CONSISTENCY: CheckConsistentTask
    }
    return task_map[task_name]


class SingleTaskManager(Singleton):
    lock = RLock()

    def __init__(self):
        if self.already_initialized():
            return
        self.peer = HAManAPI(PeerClient)
        self.task = None
        self.status = None
        self.exception = None
        self.finish_initialized()

    def check_doing(self, task):
        self.lock.acquire()
        try:
            if self.status == cons.TaskStatus.Doing:
                LOG.error("haman already in task, ignore task: %s" % task.name)
                raise Exception("The task %s is already doing now." % task.name)

            self.exception = None
            self.task = task
            self.status = cons.TaskStatus.Doing
        finally:
            self.lock.release()

    def do_task(self, task):
        task.check_permission()
        self.check_doing(task)
        self.execute_task_in_thread(task)

    @staticmethod
    def is_need_lock(task):
        return task.need_lock

    @do_in_thread()
    def execute_task_in_thread(self, task):
        try:
            task.start()
            self.status = cons.TaskStatus.Done
        except Exception as e:
            LOG.exception("failed to execute task %s in thread" % task.name)
            self.exception = e
            self.status = cons.TaskStatus.Failed

    def get_task_status(self):
        return {
            "task": self.task.name if self.task else None,
            "status": self.status,
            "error": str(self.exception) if self.exception else None,
            "result": self.task.get_result() if self.task else None
        }


class HATaskManager(SingleTaskManager):

    def __init__(self):
        if self.already_initialized():
            return

        self.peer = HAManAPI(PeerClient)
        super(HATaskManager, self).__init__()

    def build_ha(self, data):
        task = BuildHATask(data)
        self.do_task(task)

    def cancel_ha(self, include_peer=True):
        task = CancelHATask(include_peer)
        self.do_task(task)

    def cold_sync(self):
        task = ColdSyncTask()
        self.do_task(task)

    def check_consistent(self):
        task = CheckConsistentTask()
        self.do_task(task)

    def manual_switch(self):
        task = ManualSwitchTask()
        self.do_task(task)

    def follow_task(self, task_name, data):
        task_cls = get_task_cls(task_name)
        task = task_cls(data, follow=True)
        self.do_task(task)
