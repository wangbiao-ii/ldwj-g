from haman.common.utils import Singleton
from haman.service.agent import AgentManager
from haman.service.state_machine import HAMAN_STATE_MACHINE
from haman.common.constance import StateOperation
import logging

LOG = logging.getLogger(__name__)


class HealthManager(Singleton):
    health = True
    sync_confirm = True

    @classmethod
    def check(cls):
        result = True
        if HAMAN_STATE_MACHINE.is_in_operation(StateOperation.BUILD):
            LOG.debug("HAMAN is in HA building, skip health check")
        else:
            agents = AgentManager().agents.values()
            for agent in agents:
                if agent.is_switching():
                    LOG.debug("agent %s is in switching,  skip health check" % agent.name)
                    continue

                if not agent.is_health():
                    LOG.error("%s is not health" % agent.name)
                    result = False

        cls.health = result
        if not cls.sync_confirm:
            LOG.debug("sync not confirmed")

        return result & cls.sync_confirm

    @classmethod
    def get_last_health_result(cls):
        return cls.health
