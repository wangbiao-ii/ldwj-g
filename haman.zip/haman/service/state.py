from haman.common.utils import Singleton, do_in_thread, bash
from haman.common.global_value import NotifyQueue, PeerClient, KeepAlivedState
from haman.service.state_machine import HAMAN_STATE_MACHINE
from haman.service.health import HealthManager
from haman.common.api import HAManAPI
import haman.common.constance as cons
from haman.service.agent import AgentManager
from haman.common.params import Params
from haman.common.struct import State
from haman.resource.keepalived.service import KeepAlivedService
import logging
import time

LOG = logging.getLogger(__name__)


class StateManager(Singleton):

    def __init__(self):
        if self.already_initialized():
            return

        self.state: State = None
        self.params: Params = None
        self.peer = HAManAPI(PeerClient)
        self.need_sycn = False
        self.finish_initialized()

    def load_params(self):
        self.params = Params()
        self.params.load()
        LOG.debug("Load params: %s" % self.params)

    def update_params(self, params):
        LOG.debug("update params: %s" % params)
        self.params = params
        AgentManager().update_agent_params(params)
        params.write()

    def load_state(self):
        KeepAlivedState.load()
        start_state = KeepAlivedState.value

        if KeepAlivedState.value != cons.State.Standalone and not KeepAlivedService.is_active():
            start_state = cons.State.Master
            try:
                peer_state = self.peer.get_ha_state()
                LOG.debug("peer state: %s" % peer_state)
                peer_health = self.peer.is_health()
                LOG.debug("peer health: %s" % peer_health)

                if peer_state == cons.State.Master and peer_health:
                    LOG.debug("peer is health master, start as backup")

                    if self.params.preempt and self.params.master:
                        LOG.debug("find preempt as master for this device.")
                        self.need_sycn = True

                    start_state = cons.State.Backup
            except:
                LOG.exception("Peer Cannot connect, start as master")

        KeepAlivedState.update_state(start_state, False)
        HAMAN_STATE_MACHINE.set_cur_state(KeepAlivedState.value)

    def load_agent(self):
        AgentManager().setup_agents(HAMAN_STATE_MACHINE.cur_state, self.params)

    def _update_agent_state(self, notify):
        LOG.debug('update agent state')
        for agent in AgentManager().agents.values():
            try:
                agent.notify(notify.state)
            except:
                LOG.exception("Failed to notify agent %s" % agent.name)

    def _clear_agent_building_state(self):
        LOG.debug('try to clear agent building state')
        for agent in AgentManager().agents.values():
            agent.build_state = None

    def _update_state_by_order(self, notify_list):
        for notify in notify_list:
            try:
                LOG.debug("update state to %s" % notify.state)
                if HAMAN_STATE_MACHINE.cur_state == notify.state:
                    LOG.debug("notify state is same with current. ignore")
                    self._clear_agent_building_state()
                    HAMAN_STATE_MACHINE.set_cur_state(notify.state)
                    continue

                HAMAN_STATE_MACHINE.set_next_state(notify.state)
                self._update_agent_state(notify)
                HAMAN_STATE_MACHINE.set_cur_state(notify.state)
            except:
                LOG.exception("Failed to update state")

    def get_next_notify_no_wait(self):
        try:
            notify = NotifyQueue.get(block=False)
        except:
            notify = None

        return notify

    def is_vip_exist(self):
        vip = self.params.vip_list[0]['ip']
        try:
            bash("ip a | grep %s" % vip)
        except:
            return False
        return True

    def fix_notify_order_smart(self, cur_notify):
        try:
            next_notify = NotifyQueue.get(timeout=1)
            LOG.debug("get next notify %s" % next_notify)
        except:
            next_notify = None

        if next_notify:
            if next_notify.time - cur_notify.time < 1:
                LOG.debug("Two notifications received in one second")
                if HAMAN_STATE_MACHINE.cur_state == cur_notify.state and \
                        HAMAN_STATE_MACHINE.cur_state != next_notify.state:
                    LOG.debug("need fix notify order")
                    notify_list = [next_notify, cur_notify]

                    other_notify = self.get_next_notify_no_wait()
                    if other_notify:
                        notify_list.append(other_notify)
                    else:
                        LOG.debug("need update state.json file")
                        KeepAlivedState.update_state(cur_notify.state, write=True)
                else:
                    notify_list = [cur_notify, next_notify]
            else:
                notify_list = [cur_notify, next_notify]
        else:
            notify_list = [cur_notify]

        return notify_list

    @do_in_thread()
    def listen_state_change(self):
        LOG.debug("Start to deal notify.")
        from haman.service.task import HATaskManager
        while True:
            cur_notify = NotifyQueue.get()
            LOG.debug("to deal state notify %s" % cur_notify.state)
            task_status = HATaskManager().get_task_status()
            LOG.debug("task_status: %s" % task_status)
            # For keepalived v2.2.4, master device first switch to slave, so ignore the notify
            # slave is follow, when build_ha_by_agents, slave task status is done
            if task_status['task'] == cons.HATask.BUILD and task_status['status'] == cons.TaskStatus.Doing:
                if self.params.master:
                    ha_status = "Master"
                else:
                    ha_status = "Backup"
                if cur_notify.state != ha_status:
                    LOG.debug("ignore notify")
                    continue
            if task_status['task'] == cons.HATask.CANCEL and task_status['status'] == cons.TaskStatus.Doing:
                if cur_notify.state == "Backup":
                    LOG.debug("In canceling task, master device first switch to slave, ignore the notify")
                    continue
            notify_list = self.fix_notify_order_smart(cur_notify)
            self._update_state_by_order(notify_list)

    def cold_sync(self):
        retry = 30
        while retry > 0:
            try:
                LOG.debug("need to check consistent")
                self.peer.check_consistent()
                consistent_result = self.peer.wait_ha_task()
                LOG.debug("consistent: %s" % consistent_result)
                break
            except:
                LOG.error("Failed to check consistent, retry!")
                time.sleep(3)
                retry -= 1
        else:
            LOG.error("Failed to check consistent, abort!")
            return False

        try:
            for resource, consistent in consistent_result.items():
                if not consistent:
                    LOG.debug("need cold sync")
                    self.peer.cold_sync()
                    self.peer.wait_ha_task()
            return True
        except:
            LOG.exception("Failed to cold sync")
            return False

    @do_in_thread()
    def load(self):
        LOG.debug("Start to load for StateManager")
        self.load_params()
        self.load_state()
        self.load_agent()

        time.sleep(3)  # wait grpc avaliable
        start_keepalived = True
        if self.need_sycn:
            HealthManager.health = False
            start_keepalived = self.cold_sync()

        self.listen_state_change()
        if start_keepalived:
            LOG.debug("strat launch keepalived.")
            AgentManager().get_agent('keepalived').manual_launch()
            HealthManager.health = True

