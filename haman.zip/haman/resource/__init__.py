from haman.common.api import HAManAPI
from haman.common.utils import bash, do_in_thread
from haman.common.config import CONF
from haman.common.global_value import PeerClient, LocalClient
from haman.common.params import Params
from haman.common.constance import State
import logging
import time

LOG = logging.getLogger(__name__)


class ResourceConfig(object):
    name = None

    def __init__(self, configs, params: Params):
        self.configs = self.format(configs)
        self.params = params
        try:
            self.verify_config()
        except:
            raise Exception("verify config for failed")

    @staticmethod
    def format(configs):
        """
        format yaml like below:
        >    configs:
        >      - item1: value1
        >      - item2: value2
        >      - item3: value3

        return {
            item1: value1,
            item2: value2,
            item3: value3
        }
        """
        result = {}

        if not configs:
            return result

        for config in configs:
            for key, val in config.items():
                result[key] = val

        return result

    def update_params(self, params):
        self.params = params

    def get_data_path(self):
        return CONF.data_path + "/" + self.name

    def verify_config(self):
        pass

    def setup_master(self):
        pass

    def setup_backup(self):
        pass

    def setup_standalone(self):
        pass

    def clear(self):
        pass

    def write(self, config_content):
        pass

    def get_config(self, config_name, default=None):
        return self.configs.get(config_name, default)


class ResourceAgent(object):
    name = None
    peer_api = HAManAPI(PeerClient)

    def __init__(self, resource_config, launch_state=None):
        self.config = resource_config
        self.cur_state = launch_state
        self.build_state = None
        self.switching = False
        self.launched = False
        self._launch()

    def _clear_data_dir(self):
        if self.name:
            bash("rm -rf %s" % self.get_data_path())

    def _create_data_dir(self):
        if self.name:
            bash("mkdir -p %s" % self.get_data_path())

    def _execute_launch(self):
        handler_name = "launch_" + self.cur_state.lower()
        handler = getattr(self, handler_name)
        handler()
        self.launched = True

    def _launch(self):
        self._create_data_dir()
        self._execute_launch()

    def get_config(self) -> ResourceConfig:
        return self.config

    def update_params(self, params):
        self.get_config().update_params(params)

    def launch_fault(self):
        pass

    def launch_master(self):
        pass

    def launch_backup(self):
        pass

    def launch_standalone(self):
        pass

    def build(self, state):
        self.build_state = state
        self._clear_data_dir()
        self._create_data_dir()
        handler_name = "build_" + state.lower()
        handler = getattr(self, handler_name)
        handler()
        self.cur_state = state

    def build_master(self):
        pass

    def build_backup(self):
        pass

    def build_standalone(self):
        pass

    def switch_fault(self):
        pass

    def switch_master(self):
        pass

    def switch_backup(self):
        pass

    def first_notify(self, state):
        LOG.debug("ignore first notify for agent %s" % self.name)

    def _is_first_notify(self, state):
        return self.build_state == state

    def notify(self, state):
        LOG.debug("agent %s switch to %s" % (self.name, state))
        if state == State.Standalone:
            # standalone no need to notify agent
            return

        self.cur_state = state
        if self._is_first_notify(state):
            self.build_state = None
            return self.first_notify(state)

        if self.build_state:
            self.build_state = None

        try:
            self.switching = True
            handler_name = "switch_" + state.lower()
            handler = getattr(self, handler_name)
            handler()
        except Exception:
            LOG.exception("Failed to switch to %s for %s" % (state, self.name))
        finally:
            self.switching = False

    def is_switching(self):
        return self.switching

    def is_health(self):
        return True

    def is_consistent(self):
        return True

    def sync(self):
        pass

    def get_data_path(self):
        return self.config.get_data_path()

    def manual_switch(self):
        pass

    def get_config_item(self, item, default=None):
        return self.get_config().get_config(item, default)

    @classmethod
    def call_peer(cls, method_name, *args, **kwargs):
        return cls.peer_api.remote_agent_call(cls.name, method_name, *args, **kwargs)


class ResourceService(object):
    name = None

    @classmethod
    def is_active(cls):
        try:
            bash("systemctl is-active %s" % cls.name)
            return True
        except:
            return False

    @classmethod
    def start(cls):
        bash("systemctl start %s" % cls.name, ignore_error=True)

    @classmethod
    def stop(cls):
        bash("systemctl stop %s" % cls.name, ignore_error=True)

    @classmethod
    def restart(cls):
        bash("systemctl restart %s" % cls.name, ignore_error=True)

    @classmethod
    def reload(cls):
        bash("service %s reload" % cls.name, ignore_error=True)


class ResourceTask(object):

    def __init__(self, repeatable=True, repeat_interval=3):
        self.repeatable = repeatable
        self.repeat_interval = repeat_interval

        self.need_stop = False
        self.stopped = True

        self.startted = False

    def stop(self):
        self.need_stop = True

    def task(self):
        pass

    def prepare(self):
        pass

    def stop_action(self):
        pass

    def check_permission(self):
        return True

    @do_in_thread()
    def _start(self):
        try:
            self.prepare()
            self.startted = True

            while not self.need_stop:
                if self.repeatable:
                    try:
                        time.sleep(self.repeat_interval)
                        self.task()
                    except Exception as e:
                        time.sleep(self.repeat_interval)
                        LOG.error(e)
                        LOG.error("task %s error occured" % self.__class__.__name__)
                else:
                    self.task()
                    break
            self.stop_action()
        except:
            LOG.exception("error occured when startting/stopping")
        finally:
            LOG.debug("task %s stopped" % self.__class__.__name__)
            self.stopped = True

    def wait_task_stop(self):
        LOG.debug("wait task %s stop" % self.__class__.__name__)
        while not self.stopped:
            time.sleep(1)
        LOG.debug("find task %s stopped" % self.__class__.__name__)

    def wait_task_start(self):
        LOG.debug("wait task %s start" % self.__class__.__name__)
        while not self.startted:
            time.sleep(1)

            if self.stopped:
                raise Exception("Failed to start task %s" % self.__class__.__name__)

        LOG.debug("find task %s startted" % self.__class__.__name__)

    def start(self):
        if self.stopped is False:
            LOG.debug("task %s is running, cannot start again" % self.__class__.__name__)
            return False

        if not self.check_permission():
            LOG.debug("task %s is not allowed to run" % self.__class__.__name__)
            return False

        LOG.debug("start task %s" % self.__class__.__name__)
        self.stopped = False
        self.need_stop = False
        self._start()
        return True
