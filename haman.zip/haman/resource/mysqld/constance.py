class Mysql:
    class Default:
        SyncUser = "sync_user"
        SyncPass = "sync_pass"
        ConfPath = '/etc/my.cnf'
        ConfDir = '/etc/my.cnf.d'
        HAConfPath = ConfDir + "/ha.cnf"
        BinLogFormat = "mixed"
        BinLogExpireDays = "7"
