from haman.resource import ResourceService


class MysqlService(ResourceService):
    name = "mysqld"
