from haman.common.utils import bash
from haman.resource.mysqld.constance import Mysql
import logging

LOG = logging.getLogger(__name__)


class MysqlExector(object):

    def __init__(self, username, password, account_filepath=None):
        self.username = username
        self.password = password
        self.account_filepath = account_filepath

    def do(self, cmd, extra=None, options=None):
        if self.account_filepath is None:
            pre_cmd = 'mysql -u%s -p%s ' % (self.username, self.password)
        else:
            pre_cmd = 'mysql --defaults-extra-file=%s ' % self.account_filepath
        if options:
            pre_cmd += " ".join(options)

        cmd = pre_cmd + " -e " + '"' + cmd + '"'
        if extra:
            cmd += " | %s" % extra
        LOG.debug(cmd)
        return bash(cmd)

    def add_sync_count(self, allowed_hosts):
        for host in allowed_hosts:
            self.do(
                "CREATE USER IF NOT EXISTS '{user}'@'{ip}' IDENTIFIED BY '{password}'; "
                "GRANT ALL PRIVILEGES ON *.* to '{user}'@'{ip}';"
                "FLUSH PRIVILEGES;".format(
                    user=Mysql.Default.SyncUser,
                    ip=host,
                    password=Mysql.Default.SyncPass
                )
            )

    def stop_slave(self):
        self.do("STOP SLAVE;")

    def start_slave(self):
        self.do("START SLAVE;")

    def reset_bin_log(self):
        self.do("STOP SLAVE;RESET SLAVE;RESET MASTER;")

    def get_binlog_pos(self):
        pos = self.do(r"show master status \G;", "grep Position: | awk -F ': ' '{print $2}'")
        return pos

    def get_binlog_file(self):
        return self.do(r"show master status \G;", "grep File: | awk -F ': ' '{print $2}'")

    def set_master(self, master_ip, binlog_file, binlog_pos):
        LOG.debug(f'binlog_file: [{binlog_file}], binlog_pos: [{binlog_pos}]')
        self.stop_slave()
        self.do(
            "change master to GET_MASTER_PUBLIC_KEY=1,master_host='{master_ip}',master_user='{user}',master_password='{password}'," \
            "master_log_file='{binlog_file}',master_log_pos={binlog_pos};".format(
                master_ip=master_ip,
                user=Mysql.Default.SyncUser,
                password=Mysql.Default.SyncPass,
                binlog_file=binlog_file,
                binlog_pos=binlog_pos
            )
        )
        self.start_slave()

    def stop_master(self):
        self.do(
            "STOP slave;RESET slave;RESET master;DELETE FROM mysql.user WHERE user='sync_user';FLUSH PRIVILEGES;"
        )

    def data_sync(self, db_list, ignore_tables, to_ip):
        if self.account_filepath is None:
            account = '-u%s -p%' % (self.username, self.password)
        else:
            account = '--defaults-extra-file=%s' % self.account_filepath

        # dump_cmd = "mysqldump -u{username} -p{password} --master-data=1 --single-transaction".format(
        #     username=self.username,
        #     password=self.password
        # )
        dump_cmd = "mysqldump {account} --master-data=1 --single-transaction".format(
            account=account
        )
        if db_list:
            dump_cmd += " --databases %s" % " ".join(db_list)

        if ignore_tables:
            for table in ignore_tables:
                dump_cmd += " --ignore-table=%s" % table

        sync_cmd = dump_cmd + " | mysql -u{sync_user} -p{sync_pass} --host={peer_ip}".format(
            sync_user=Mysql.Default.SyncUser,
            sync_pass=Mysql.Default.SyncPass,
            peer_ip=to_ip
        )

        bash(sync_cmd)

    def get_tables_md5(self, db_list, ignore_tables):
        result = {}
        filter_str = "where table_schema in ('%s');" % "', '".join(db_list)
        cmd = "select table_schema, table_name from information_schema.tables " + filter_str
        tables = self.do(cmd, "grep -E '^|'", options=['-N'])
        for table_info in tables.splitlines():
            db_name, table_name = table_info.split('\t')
            t_name = "%s.%s" % (db_name, table_name)
            if t_name in ignore_tables:
                continue
            checksum = self.do("checksum table %s\G;" % t_name, " grep Checksum | awk -F ': ' '{print $2}'")
            result[t_name] = checksum
        return result
