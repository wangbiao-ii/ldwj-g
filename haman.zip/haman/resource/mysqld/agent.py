import os

from haman.resource import ResourceAgent
from haman.resource.mysqld.constance import Mysql
from haman.resource.mysqld.service import MysqlService
from haman.common.utils import get_nic_address, bash
from haman.resource.mysqld.utils import MysqlExector
import logging

LOG = logging.getLogger(__name__)


class Agent(ResourceAgent):
    cmd_exector = None

    def launch_master(self):
        if not MysqlService.is_active():
            MysqlService.restart()

    def launch_backup(self):
        if not MysqlService.is_active():
            MysqlService.restart()

    def launch_standalone(self):
        if not MysqlService.is_active():
            MysqlService.restart()

    def build_master(self):
        self.config_master()
        self.call_peer('config_backup')
        self.set_slave_master()

    def build_backup(self):
        self.set_slave_master()

    def build_standalone(self):
        self.get_config().clear()
        self.get_cmd_exector().stop_master()

    def is_health(self):
        return MysqlService.is_active()

    def sync(self):
        self.reset_binlog()
        self.call_peer('reset_binlog')
        try:
            db_list = self.get_config_item('sync_db', [])
            ignore_tables = self.get_config_item('replicate-wild-ignore-table', [])
            self.get_cmd_exector().data_sync(db_list, ignore_tables, self.get_peer_data_ip())
            LOG.debug("sync mysql success")
        finally:
            self.set_slave_master()
            self.call_peer('set_slave_master')

    def is_consistent(self):
        local_table_md5sum = self.get_db_md5sum()
        peer_table_md5sum = self.call_peer('get_db_md5sum')

        if len(local_table_md5sum) != len(peer_table_md5sum):
            LOG.error("table num is not same")
            LOG.debug(local_table_md5sum.keys())
            LOG.debug(peer_table_md5sum.keys())
            return False

        for key, value in local_table_md5sum.items():
            if peer_table_md5sum.get(key) != value:
                LOG.debug("table %s is not consistency" % key)
                return False

        return True

    def get_db_md5sum(self):
        db_list = self.get_config_item('sync_db', [])
        ignore_tables = self.get_config_item('replicate-wild-ignore-table', [])
        return self.get_cmd_exector().get_tables_md5(db_list, ignore_tables)

    def get_cmd_exector(self, reset=False):
        self.confirm_account_file()
        if not self.cmd_exector or reset:
            self.cmd_exector = MysqlExector(
                username=self.get_config_item('username'),
                password=self.get_config_item('password'),
                account_filepath=self.get_account_filepath()
            )
        return self.cmd_exector

    def confirm_account_file(self):
        client_file_path = self.get_account_filepath()
        if os.path.exists(client_file_path):
            return

        content = "[client]\n" \
                  "user=%s\n" % self.get_config_item('username') + \
                  "password=%s" % self.get_config_item('password')
        with open(client_file_path, 'w') as f:
            f.write(content)

    def get_account_filepath(self):
        # will be deleted when build_xxx called
        return self.get_data_path() + '/client.cnf'

    def set_master(self, binlog_file, binlog_pos):
        master_ip = self.get_config().params.peer_data_interface_ip
        self.get_cmd_exector().set_master(master_ip, binlog_file, binlog_pos)

    def reset_binlog(self):
        return self.get_cmd_exector().reset_bin_log()

    def get_binlog_pos(self):
        return self.get_cmd_exector().get_binlog_pos()

    def get_binlog_file(self):
        return self.get_cmd_exector().get_binlog_file()

    @staticmethod
    def is_active(self):
        return MysqlService.is_active()

    def get_allowed_hosts(self):
        peer_host = self.get_config().params.peer_data_interface_ip
        local_host = self.get_config().params.local_data_interface_ip
        return [
            peer_host,
            local_host
        ]

    def config_master(self):
        content = self.get_config().setup_master()
        self.get_config().write(content)
        self.clear_bind_addr()
        self.include_ha_conf()
        MysqlService.restart()
        if not MysqlService.is_active():
            raise Exception("MysqlService service is not active")
        self.get_cmd_exector().add_sync_count(self.get_allowed_hosts())

    def config_backup(self):
        content = self.get_config().setup_backup()
        self.get_config().write(content)
        self.clear_bind_addr()
        self.include_ha_conf()
        MysqlService.restart()
        if not MysqlService.is_active():
            raise Exception("MysqlService service is not active")
        self.get_cmd_exector().add_sync_count(self.get_allowed_hosts())

    def set_slave_master(self):
        pos = self.call_peer('get_binlog_pos')
        file = self.call_peer('get_binlog_file')
        self.set_master(file, pos)

    def get_peer_data_ip(self):
        return self.get_config().params.peer_data_interface_ip

    def clear_bind_addr(self):
        bash("sed -i '/bind_address/d' %s" % Mysql.Default.ConfPath)

    def include_ha_conf(self):
        output = bash("grep '^!includedir %s' %s" % (Mysql.Default.ConfDir, Mysql.Default.ConfPath), ignore_error=True)
        if not output:
            bash("sed -i '$a\\\\n!includedir %s' %s" % (Mysql.Default.ConfDir, Mysql.Default.ConfPath))
