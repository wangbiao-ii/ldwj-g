from haman.resource import ResourceConfig
from haman.resource.mysqld.constance import Mysql
from haman.common.utils import bash
import os


class Config(ResourceConfig):
    name = 'mysqld'

    def check(self):
        if self.get_config("ha_cnf_path"):
            path = self.get_config("ha_cnf_path")
            if os.path.isdir(path):
                raise Exception("ha_cnf_path is not correct for mysqld")

    def get_ignore_tables(self):
        content = ""
        for table in self.get_config('replicate-wild-ignore-table', []):
            content += "replicate-wild-ignore-table = %s\n" % table
        return content

    def get_binlog_ignore_db(self):
        content = ""
        for db in self.get_config('binlog-ignore-db', []):
            content += "binlog-ignore-db = %s\n" % db
        return content

    def get_binlog_do_db(self):
        content = ""
        for db in self.get_config('sync_db', []):
            content += "binlog-do-db = %s\n" % db
        return content

    def setup_master(self):
        content = "[server]\n" \
                  "server-id = 1\n" \
                  "log-bin = mysql-bin\n" \
                  "binlog_format = %s\n" % self.get_config("binlog_format", Mysql.Default.BinLogFormat) + \
                  "log-slave-updates = 1\n" \
                  "expire_logs_days = %s\n" % self.get_config("binlog_expire_days", Mysql.Default.BinLogExpireDays) + \
                  "auto-increment-increment = 2\n" \
                  "auto-increment-offset = 1\n" \
                  "slave_skip_errors = 1032,1062,1051\n"

        content += self.get_binlog_do_db()
        content += self.get_ignore_tables()
        content += self.get_binlog_ignore_db()

        return content

    def setup_backup(self):
        content = "[server]\n" \
                  "server-id = 2\n" \
                  "log-bin = mysql-bin\n" \
                  "binlog_format = %s\n" % self.get_config("binlog_format", Mysql.Default.BinLogFormat) + \
                  "log-slave-updates = 1\n" \
                  "expire_logs_days = %s\n" % self.get_config("binlog_expire_days", Mysql.Default.BinLogExpireDays) + \
                  "auto-increment-increment = 2\n" \
                  "auto-increment-offset = 2\n" \
                  "slave_skip_errors = 1032,1062,1051\n"

        content += self.get_ignore_tables()
        content += self.get_binlog_ignore_db()

        return content

    def write(self, content):
        path = self.get_config("ha_cnf_path", Mysql.Default.HAConfPath)
        with open(path, "w") as file:
            file.write(content)
        bash("chmod 644 %s" % path)
        # print(content)

    def clear(self):
        path = self.get_config("ha_cnf_path", Mysql.Default.HAConfPath)
        bash("rm -rf %s" % path)
