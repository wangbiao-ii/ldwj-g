class Rsync:
    ConfPath = "/etc/rsyncd.conf"

    class Default:
        MAXConnections = 5
        TIMEOUT = 300
        SecretPath = "/etc/rsync.passwd"
        Secret = "hillstone"
