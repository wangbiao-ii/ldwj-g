from haman.resource import ResourceAgent
from haman.resource.rsyncd.service import RsyncService
from haman.resource.lsyncd.service import LsyncdService
from haman.common.constance import State
import logging

LOG = logging.getLogger(__name__)


class Agent(ResourceAgent):

    def restart_rsyncd(self):
        if not RsyncService.is_active():
            RsyncService.restart()

    def restart_lsyncd(self):
        if not LsyncdService.is_active():
            LOG.debug("start lsyncd")
            LsyncdService.restart()

    def confirm_peer_lsyncd(self):
        try:
            self.call_peer("restart_lsyncd")
        except:
            LOG.warning("Failed to confirm peer lsyncd service")

    def launch_backup(self):

        if not RsyncService.is_active():
            LOG.debug("start rsyncd")
            RsyncService.restart()
            self.confirm_peer_lsyncd()

    def build_master(self):
        content = self.get_config().setup_master()
        self.get_config().write(content)
        RsyncService.stop()

    def build_backup(self):
        content = self.get_config().setup_backup()
        self.get_config().write(content)
        RsyncService.restart()
        if not RsyncService.is_active():
            raise Exception("RsyncService service is not active")

    def build_standalone(self):
        RsyncService.stop()

    def switch_master(self):
        RsyncService.stop()

    def switch_backup(self):
        RsyncService.restart()
        self.confirm_peer_lsyncd()

    def is_health(self):
        if self.cur_state == State.Backup:
            return RsyncService.is_active()
        return True
