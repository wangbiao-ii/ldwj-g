from haman.resource import ResourceService


class RsyncService(ResourceService):
    name = "rsyncd"
