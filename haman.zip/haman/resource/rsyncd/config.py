from haman.resource.rsyncd.constance import Rsync
from haman.resource import ResourceConfig
from haman.common.utils import bash, get_nic_address


class Config(ResourceConfig):
    name = 'rsyncd'

    def format_modules(self):
        module_list = []
        modules = self.get_config('modules', {})
        for module_name, module_dict in modules.items():
            path = module_dict['path']
            module_list.append({
                'module': module_name,
                'source_path': path,
                'exclude': module_dict.get('exclude', [])
            })
        return module_list

    def generate(self):
        peer_ip = self.params.peer_data_interface_ip + ', ' + self.params.local_data_interface_ip

        content = "uid = root\n" \
                  "gid = root\n" \
                  "use chroot = yes\n" \
                  "max connections = %d\n" % self.get_config('max_connections', Rsync.Default.MAXConnections) + \
                  "timeout = %d\n" % self.get_config('timeout', Rsync.Default.TIMEOUT) + \
                  "pid file = /var/run/rsyncd.pid\n" \
                  "lock file = /var/run/rsync.lock\n" \
                  "log file = /var/log/rsyncd.log\n" \
                  "hosts allow = %s\n" % peer_ip

        # add modules
        modules_list = self.format_modules()
        for sync in modules_list:
            content += "[%s]\n" % sync['module'] + \
                       "path = %s\n" % sync['source_path'] + \
                       "ignore errors = true\n" \
                       "read only = no\n" \
                       "secrets file = %s\n" % self.get_config("secret_file", Rsync.Default.SecretPath) + \
                       "auth users = rsync\n"

        return content

    def write(self, content):
        with open(Rsync.ConfPath, "w") as file:
            file.write(content)

        secret_path = self.get_config("secret_file", Rsync.Default.SecretPath)
        secret = "rsync:" + self.get_config("secret", Rsync.Default.Secret) + "\n"
        with open(secret_path, "w") as file:
            file.write(secret)
        bash("chmod 600 %s" % secret_path)

    def setup_master(self):
        return self.generate()

    def setup_backup(self):
        return self.generate()
