from haman.resource import ResourceConfig


class Config(ResourceConfig):
    name = "hems"

    def format_watch_files(self):
        watch_files = []
        for file_dict in self.get_config('watch_files', []):
            for file_path, cmd in file_dict.items():
                watch_files.append({
                    'file_path': file_path,
                    'cmd': cmd
                })
        return watch_files
