from haman.resource import ResourceTask
import subprocess
import logging
import os

LOG = logging.getLogger(__name__)


class WatchFilesTask(ResourceTask):

    def __init__(self, files):
        self.files = files
        super(WatchFilesTask, self).__init__()

    def check_permission(self):
        if not self.files:
            LOG.debug("No files need check")
            return False
        return True

    def get_mtime(self, file_path):
        if not os.path.exists(file_path):
            return None
        else:
            return os.path.getmtime(file_path)

    def get_init_modify_time(self):
        for file in self.files:
            LOG.debug("watch file: %s" % file['file_path'])
            file['mtime'] = self.get_mtime(file['file_path'])

    def task(self):
        for file in self.files:
            mtime = self.get_mtime(file['file_path'])
            if mtime != file['mtime']:
                file['mtime'] = mtime
                LOG.debug("find file %s changed" % file['file_path'])
                LOG.debug(subprocess.getstatusoutput(file['cmd']))

    def prepare(self):
        self.get_init_modify_time()
