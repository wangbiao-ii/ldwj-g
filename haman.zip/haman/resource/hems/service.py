from haman.resource import ResourceService


class HttpdService(ResourceService):
    name = "httpd"


class NtpdService(ResourceService):
    name = "ntpd"


class CrondService(ResourceService):
    name = "crond"


class IptableService(ResourceService):
    name = "iptables"
