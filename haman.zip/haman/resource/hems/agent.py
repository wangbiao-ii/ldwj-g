from haman.resource import ResourceAgent
import haman.resource.hems.service as service
from haman.common.utils import do_in_thread
from haman.common.constance import State
from haman.resource.hems.task import WatchFilesTask
from haman.resource.hems.config import Config
import requests
import time
import logging

LOG = logging.getLogger(__name__)


class Agent(ResourceAgent):
    watch_file_task = None

    def get_config(self) -> Config:
        return self.config

    def start_watch_file(self):
        if not self.watch_file_task:
            self.watch_file_task = WatchFilesTask(self.get_config().format_watch_files())
        self.watch_file_task.start()
        self.watch_file_task.wait_task_start()

    def stop_watch_file(self):
        if self.watch_file_task:
            self.watch_file_task.stop()
            self.watch_file_task.wait_task_stop()

    def restart_hot_sync(self):
        self.stop_watch_file()
        self.start_watch_file()

    def launch_backup(self):
        LOG.debug("cur state is backup, need start file watch task.")
        self.start_watch_file()

    def notify_hems(self, role):
        retry = 3
        while retry > 0:
            try:
                requests.put(url="http://127.0.0.1:8001/v1/cloudpano/ha/notify", json={'role': role})
                break
            except:
                LOG.warning("Failed to notify, need retry")
                retry -= 1
                time.sleep(2)

    def first_notify(self, state):
        self.notify_hems(state)
        if state == State.Backup:
            self.start_watch_file()
        else:
            self.stop_watch_file()

    def switch_master(self):
        LOG.debug("switch master for %s" % self.name)
        self.notify_hems(State.Master)
        self.stop_watch_file()
        service.NtpdService.restart()
        service.CrondService.restart()
        service.IptableService.restart()

    @do_in_thread()
    def restart_hsecaas(self):
        LOG.debug("restart hems after 5 seconds.")
        time.sleep(5)
        service.HttpdService.restart()

    def switch_backup(self):
        LOG.debug("switch backup for %s" % self.name)
        self.notify_hems(State.Backup)
        self.start_watch_file()
        self.restart_hsecaas()

    @do_in_thread()
    def _restore_standalone(self):
        self.stop_watch_file()
        self.watch_file_task = None
        service.NtpdService.restart()
        service.CrondService.restart()
        service.IptableService.restart()

    def build_standalone(self):
        self.notify_hems(State.Standalone)
        self._restore_standalone()

    def switch_fault(self):
        self.notify_hems(State.Fault)

    def is_health(self):
        return service.HttpdService.is_active()
