from haman.resource import ResourceTask
from haman.resource.keepalived.service import KeepAlivedService
from haman.resource.keepalived.utils import clear_vips
from haman.common.global_value import LocalClient
from haman.common.api import HAManAPI
from haman.common.constance import State
import logging
import time

LOG = logging.getLogger(__name__)


class KeepalivedMonitorTask(ResourceTask):

    def __init__(self, vip_list):
        self.vip_list = vip_list
        self.dead = False
        self.local_api = HAManAPI(LocalClient)
        super(KeepalivedMonitorTask, self).__init__()

    def task(self):
        if not KeepAlivedService.is_active():
            # may in restart, wait 3 seconds
            time.sleep(3)

            if KeepAlivedService.is_active():
                return

            if not self.dead:
                LOG.debug("keepalived is dead")
                clear_vips(self.vip_list)
                self.dead = True
                self.local_api.notify(State.Fault)
                KeepAlivedService.restart()

        else:
            if self.dead:
                LOG.debug("keepalived is alived")
                self.dead = False
