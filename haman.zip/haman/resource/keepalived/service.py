from haman.resource import ResourceService


class KeepAlivedService(ResourceService):
    name = "keepalived"
