import logging

from haman.common.utils import bash
from haman.resource.keepalived.constance import KeepAlived

LOG = logging.getLogger(__name__)


def get_current_priority():
    return int(bash("grep 'priority' %s  | awk -F ' ' '{print $2}'" % KeepAlived.ConfPath))


def get_priority_step(preempt):
    return 10 if not preempt else 20


def change_current_priority(new_priority):
    cmd = "sed -i '/    priority /c\    priority %d' %s" % (new_priority, KeepAlived.ConfPath)
    LOG.debug(cmd)
    bash(cmd)


def change_preempt(preempt):
    bash("sed -i '/nopreempt/d' /etc/keepalived/keepalived.conf")
    if not preempt:
        bash("sed -i '/    advert_int/a\    nopreempt' %s" % KeepAlived.ConfPath)


def restore_switched_priority(preempt):
    current_priority = get_current_priority()
    priority_step = get_priority_step(preempt)
    new_priority = current_priority + priority_step
    change_current_priority(new_priority)


def clear_vips(vip_list):
    for vip in vip_list:
        bash("ip addr | grep %s && ip addr delete %s dev %s" % (vip['ip'], vip['ip'], vip['dev']),
             ignore_error=True)
