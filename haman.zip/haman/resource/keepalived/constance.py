class KeepAlived:
    RouterId = "GlobalRouterID"

    ConfPath = "/etc/keepalived/keepalived.conf"

    class State:
        Master = "MASTER"
        Backup = "BACKUP"
    class Script:
        class Health:
            Name = "health_check"
            DefaultInterval = 10
            DefaultFall = 3
            DefaultWeight = -50

        class Switch:
            Name = "manual_switch"
            DefaultInterval = 3
            DefaultFall = 1
            DefaultWeight = -20

    class Instance:
        DefaultName = "VI_1"
        DefaultRouterID = 1
        DefaultMasterPriority = 100
        DefaultBackupPriority = 90
