from haman.resource import ResourceConfig
import haman.resource.keepalived.constance as cons
import haman.cmd.notify as notify
import haman.cmd.health as health


class VRRPScript(object):

    def __init__(self, name, script, interval, weight, fall):
        self.name = name
        self.script = script
        self.interval = interval
        self.weight = weight
        self.fall = fall

    def generate(self):
        return "vrrp_script %s {\n" \
               "    script \"%s\"\n" \
               "    interval %d\n" \
               "    weight %d\n" \
               "    fall %d\n" \
               "}" % (
                   self.name, self.script, self.interval, self.weight, self.fall)


class GlobalDefs(object):

    def __init__(self, router_id):
        self.router_id = router_id

    def generate(self):
        return "global_defs {\n    router_id %s\n    script_user root\n    enable_script_security\n}" % self.router_id


class VRRPSyncGroup(object):

    def __init__(self, name, instance_name):
        self.name = name
        self.instance_name = instance_name

    def generate(self):
        return "vrrp_sync_group %s {\n" \
               "    group {\n" \
               "        %s\n" \
               "    }\n" \
               "}" % (self.name, self.instance_name)


class VirtualIPAddr(object):

    def __init__(self, ip, dev, label=None):
        self.ip = ip
        self.dev = dev
        self.label = label

    def generate(self):
        content = "%s dev %s" % (self.ip, self.dev)
        if self.label:
            content += " label %s" % self.label
        return content


class VRRPInstance(object):

    def __init__(self, name, state, interface, virtual_router_id, priority, preempt, track_interfaces, track_scripts,
                 unicast_src_ip, unicast_peer_ip, virtual_ipaddress, advert_interval=3):
        self.name = name
        self.state = state
        self.interface = interface
        self.virtual_router_id = virtual_router_id
        self.priority = priority
        self.preempt = preempt
        self.track_interfaces = track_interfaces
        self.track_scripts = track_scripts
        self.unicast_src_ip = unicast_src_ip
        self.unicast_peer_ip = unicast_peer_ip
        self.virtual_ipaddress = virtual_ipaddress
        self.advert_interval = advert_interval

    def generate(self):
        notify_path = notify.__file__
        preempt = "nopreempt" if not self.preempt else ""
        content = "vrrp_instance %s {\n" % self.name + \
                  "    state %s\n" % self.state + \
                  "    interface %s\n" % self.interface + \
                  "    virtual_router_id %d\n" % self.virtual_router_id + \
                  "    priority %d\n" % self.priority + \
                  "    advert_int %d\n" % self.advert_interval + \
                  "    %s\n" % preempt + \
                  "    track_interface {\n" \
                  "        %s" % "\n        ".join(self.track_interfaces) + "\n" + \
                  "    }\n" \
                  "    track_script {\n" \
                  "        %s" % "\n        ".join(self.track_scripts) + "\n" + \
                  "    }\n" \
                  "    authentication {\n" \
                  "        auth_type PASS\n" \
                  "        auth_pass k#Jv3uS@\n" \
                  "    }\n" \
                  "    notify_master \"/usr/bin/python3 %s Master\"\n" % notify_path + \
                  "    notify_backup \"/usr/bin/python3 %s Backup\"\n" % notify_path + \
                  "    notify_fault  \"/usr/bin/python3 %s Fault\"\n" % notify_path + \
                  "    unicast_src_ip %s\n" % self.unicast_src_ip + \
                  "    unicast_peer {\n" \
                  "        %s\n" % self.unicast_peer_ip + \
                  "    }\n" \
                  "    virtual_ipaddress {\n" \
                  "        %s" % "\n        ".join([a.generate() for a in self.virtual_ipaddress]) + "\n" + \
                  "    }\n" \
                  "}"
        return content


class Config(ResourceConfig):
    name = 'keepalived'

    def __init__(self, configs, params):
        super(Config, self).__init__(configs, params)

        self.vrrp_scripts = []
        self.global_defs = None
        self.vrrp_instances = []
        self.vrrp_sync_group = None

    def verify_config(self):
        group_id = self.params.group_id
        if group_id is None:
            return

        group_id = int(group_id)
        if group_id > 255 or group_id < 1:
            raise Exception("Group ID is not correct")

    def clear(self):
        self.vrrp_scripts = []
        self.global_defs = None
        self.vrrp_instances = []
        self.vrrp_sync_group = None

    def setup_common(self):
        self.global_defs = GlobalDefs(self.get_config("global_router_id", cons.KeepAlived.RouterId))
        self.vrrp_scripts.extend([
            VRRPScript(
                name=cons.KeepAlived.Script.Health.Name,
                script="/usr/bin/python3 %s" % health.__file__,
                interval=self.get_config("health_check_interval", cons.KeepAlived.Script.Health.DefaultInterval),
                weight=cons.KeepAlived.Script.Health.DefaultWeight,
                fall=self.get_config("health_check_fall", cons.KeepAlived.Script.Health.DefaultFall)
            )
        ])
        self.vrrp_sync_group = VRRPSyncGroup("VG_1", "VI_1")

    def setup_instance(self, state):
        ctl_interface = self.params.ctl_interface
        data_interface = self.params.data_interface
        interface_list = self.get_config('extra_track_interfaces', [])
        interface_list.extend([ctl_interface, data_interface])
        track_interfaces = list(set(interface_list))
        unicast_src_ip = self.params.local_ctl_interface_ip
        unicast_peer_ip = self.params.peer_ctl_interface_ip
        advert_interval = int(self.params.hello_interval)

        if self.params.preempt:
            # 如果抢占，则两个节点优先级不同，优先级高的会抢占
            if state == cons.KeepAlived.State.Master:
                priority = cons.KeepAlived.Instance.DefaultMasterPriority
            else:
                priority = cons.KeepAlived.Instance.DefaultBackupPriority
        else:
            # 如果不抢占，两个节点优先级相同
            priority = cons.KeepAlived.Instance.DefaultMasterPriority

        virtual_ipaddress_list = [VirtualIPAddr(a['ip'], a['dev']) for a in self.params.vip_list]

        self.vrrp_instances.append(
            VRRPInstance(
                name=self.get_config("instance_name", cons.KeepAlived.Instance.DefaultName),
                state=state,
                interface=ctl_interface,
                virtual_router_id=int(self.params.group_id),
                priority=priority,
                preempt=True,
                track_interfaces=track_interfaces,
                track_scripts=[cons.KeepAlived.Script.Health.Name],
                unicast_src_ip=unicast_src_ip,
                unicast_peer_ip=unicast_peer_ip,
                virtual_ipaddress=virtual_ipaddress_list,
                advert_interval=advert_interval
            )
        )

    def setup_master(self):
        self.clear()
        self.setup_common()
        self.setup_instance(cons.KeepAlived.State.Master)
        return self.generate()

    def setup_backup(self):
        self.clear()
        self.setup_common()
        self.setup_instance(cons.KeepAlived.State.Backup)
        return self.generate()

    def generate(self):
        content = "! Configuration File for keepalived\n"
        content += self.global_defs.generate() + "\n"
        for vrrp_script in self.vrrp_scripts:
            content += vrrp_script.generate() + "\n"

        for vrrp_instance in self.vrrp_instances:
            content += vrrp_instance.generate() + "\n"

        # content += self.vrrp_sync_group.generate()
        return content

    def write(self, content):
        with open(cons.KeepAlived.ConfPath, "w") as file:
            file.write(content)
