from haman.resource import ResourceAgent
from haman.resource.keepalived.service import KeepAlivedService
from haman.common.utils import bash
from haman.common.constance import State
import haman.resource.keepalived.utils as k_utils
from haman.resource.keepalived.task import KeepalivedMonitorTask
import os
import logging

LOG = logging.getLogger(__name__)


class Agent(ResourceAgent):
    monitor_task = None

    def _execute_launch(self):
        pass

    def manual_launch(self):
        if self.launched:
            LOG.debug("keepalived already launched, skip")
            return
        handler_name = "launch_" + self.cur_state.lower()
        handler = getattr(self, handler_name)
        handler()
        self.launched = True

    def start_monitor_task(self):
        if not self.monitor_task:
            self.monitor_task = KeepalivedMonitorTask(self.get_config().params.vip_list)
        self.monitor_task.start()
        self.monitor_task.wait_task_start()

    def stop_monitor_task(self):
        if self.monitor_task:
            self.monitor_task.stop()
            self.monitor_task.wait_task_stop()
            self.monitor_task = None

    def launch_master(self):
        self.try_to_restore_priority()
        if not KeepAlivedService.is_active():
            LOG.debug("Need to start keepalived")
            KeepAlivedService.restart()
        self.start_monitor_task()

    def launch_backup(self):
        if not KeepAlivedService.is_active():
            KeepAlivedService.restart()
        self.start_monitor_task()

    def build_master(self):
        self.clear_switch_file()
        # LOG.debug("params in keepalived %s" % self.get_config().params)
        content = self.get_config().setup_master()
        self.get_config().write(content)
        KeepAlivedService.restart()
        if not KeepAlivedService.is_active():
            raise Exception("keepalived service is not active")
        self.start_monitor_task()

    def build_backup(self):
        self.clear_switch_file()
        content = self.get_config().setup_backup()
        self.get_config().write(content)
        KeepAlivedService.restart()
        if not KeepAlivedService.is_active():
            raise Exception("keepalived service is not active")
        self.start_monitor_task()

    def build_standalone(self):
        self.stop_monitor_task()
        k_utils.clear_vips(self.get_config().params.vip_list)
        self.clear_switch_file()
        KeepAlivedService.stop()

    def get_switch_file_path(self):
        return self.get_data_path() + "/switching"

    def is_exist_switch_file(self):
        return os.path.exists(self.get_switch_file_path())

    def clear_switch_file(self):
        bash("rm -rf %s" % self.get_switch_file_path())

    def create_switch_file(self):
        bash("touch %s" % self.get_switch_file_path())

    def try_to_restore_priority(self, reload=True):
        if self.is_exist_switch_file():
            k_utils.restore_switched_priority(self.get_config().params.preempt)

            if KeepAlivedService.is_active() and reload:
                KeepAlivedService.reload()

            self.clear_switch_file()

    def switch_master(self):
        self.try_to_restore_priority()

    def is_health(self):
        return KeepAlivedService.is_active()

    def manual_switch(self):

        if self.cur_state != State.Master:
            raise Exception("current state cannot switch")

        self.try_to_restore_priority(reload=False)

        current_priority = k_utils.get_current_priority()
        priority_step = k_utils.get_priority_step(self.get_config().params.preempt)
        new_priority = current_priority - priority_step
        k_utils.change_current_priority(new_priority)

        self.create_switch_file()

        KeepAlivedService.reload()

        self.call_peer("try_to_restore_priority")
