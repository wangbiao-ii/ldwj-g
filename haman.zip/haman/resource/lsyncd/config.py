from haman.resource import ResourceConfig
from haman.resource.lsyncd.constance import Lsyncd
from haman.common.utils import bash
import os

class Config(ResourceConfig):
    name = 'lsyncd'

    def format_modules(self):
        module_list = []
        modules = self.get_config('modules', {})
        for module_name, module_dict in modules.items():
            path = module_dict['path']
            module_list.append({
                'module': module_name,
                'source_path': path,
                'exclude': module_dict.get('exclude', []),
                'only': module_dict.get('only', [])
            })
        return module_list

    def prepare_modules(self, modules):
        for module in modules:
            path = module['source_path']
            if not os.path.exists(path):
                bash('mkdir -p %s' % path, ignore_error=True)
                bash('chmod 777 %s -R' % path, ignore_error=True)

    def _gen_settings(self):
        content = "settings {\n" \
                  "    logfile = \"%s\",\n" % self.get_config('log_file', Lsyncd.DefaultLogFile) + \
                  "    statusFile = \"%s\",\n" % self.get_config('status_file', Lsyncd.DefaultStatusFile) + \
                  "    inotifyMode = \"CloseWrite or Modify\",\n" \
                  "    maxProcesses = %d\n" % self.get_config('max_process', Lsyncd.DefaultMaxProcess) + \
                  "}\n"
        return content

    def _gen_sync(self):
        peer_ip = self.params.peer_data_interface_ip
        content = ""
        modules_list = self.format_modules()
        self.prepare_modules(modules_list)
        for module in modules_list:
            content += "sync {\n" \
                       "    default.rsync,\n" \
                       "    source = \"%s\",\n" % module['source_path'] + \
                       "    target = \"rsync@%s::%s\",\n" % (peer_ip, module['module']) + \
                       "    delete= true,\n" \
                       "    delay = 5,\n" \
                       "    rsync = {\n" \
                       "        binary = \"/usr/bin/rsync\",\n" \
                       "        archive = true,\n" \
                       "        compress = true,\n" \
                       "        verbose = true,\n" \
                       "        password_file = \"%s\",\n" % self.get_config("secret_file", Lsyncd.SecretPath)
            if module['only']:
                content += "        _extra = {\n"
                for file in module['only']:
                    content += "            \"--include=%s\",\n" % file
                content += "            \"--exclude=*\",\n" \
                           "        }\n"
            content += "    },\n"

            if module['exclude']:
                content += "    exclude = {\n"
                for file in module['exclude']:
                    content += "        '%s',\n" % file
                content += "    }\n"

            content += "}\n"
        return content

    def generate(self):
        content = self._gen_settings()
        content += self._gen_sync()
        return content

    def setup_backup(self):
        return self.generate()

    def setup_master(self):
        return self.generate()

    # def _save_exclude_file(self):
    #     modules_list = self.format_modules()
    #     for module in modules_list:
    #         content = "\n".join(module['exclude'])
    #
    #         file_path = self.get_data_path() + '/%s.exclude' % module['module']
    #         with open(file_path, "w") as file:
    #             file.write(content)

    def _save_secret_file(self):
        secret_path = self.get_config("secret_file", Lsyncd.SecretPath)
        secret = self.get_config("secret", Lsyncd.DefaultSecret) + "\n"
        with open(secret_path, "w") as file:
            file.write(secret)
        bash("chmod 600 %s" % secret_path)

    def _save_config_file(self, content):
        with open(Lsyncd.ConfPath, "w") as file:
            file.write(content)

    def write(self, content):
        self._save_config_file(content)
        self._save_secret_file()
        # self._save_exclude_file()
