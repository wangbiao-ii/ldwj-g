from haman.resource import ResourceAgent
from haman.resource.lsyncd.service import LsyncdService
from haman.common.constance import State
from haman.resource.lsyncd.constance import Lsyncd
from haman.common.utils import bash
from haman.resource.lsyncd.config import Config
from haman.resource.rsyncd.service import RsyncService
import logging

LOG = logging.getLogger(__name__)


class Agent(ResourceAgent):
    need_try_restart = False
    health_caller = None

    def get_config(self) -> Config:
        return self.config

    def launch_master(self):
        if not LsyncdService.is_active():
            LsyncdService.restart()

    def build_master(self):
        content = self.get_config().setup_master()
        self.get_config().write(content)
        LsyncdService.restart()
        if not LsyncdService.is_active():
            raise Exception("LsyncdService service is not active")

    def build_backup(self):
        content = self.get_config().setup_backup()
        self.get_config().write(content)
        LsyncdService.stop()

    def build_standalone(self):
        LsyncdService.stop()

    def switch_master(self):
        LsyncdService.restart()

    def switch_backup(self):
        LsyncdService.stop()

    def is_rsyncd_active(self):
        return RsyncService.is_active()

    def check_peer_rsyncd(self):
        if not self.health_caller:
            self.health_caller = self.peer_api.client.get_caller(timeout=3)
        return self.health_caller("remote_agent_call", self.name, "is_rsyncd_active")

    def is_health(self):
        if self.cur_state == State.Master:
            result = LsyncdService.is_active()
            if not result:

                try:
                    remote_rsyncd_active = self.check_peer_rsyncd()
                except:
                    remote_rsyncd_active = False

                if not remote_rsyncd_active:
                    return True

            return result

        return True

    def _get_exclude_args(self, module):
        excludes = module['exclude']
        onlys = module['only']
        exclude_cmd = ""
        if excludes:
            for file in excludes:
                exclude_cmd += "--exclude=%s " % file

        if onlys:
            for file in onlys:
                exclude_cmd += "--include=%s " % file
            exclude_cmd += "--exclude=* "

        return exclude_cmd

    def _is_same(self, peer_ip, module, secret_file):
        module_name = module['module']
        path = module['source_path']
        exclude_cmd = self._get_exclude_args(module)
        cmd = "rsync -arnc {exclude_cmd} --delete --out-format='%n' {path}/ rsync@{peer_ip}::{module}/ --password-file {secret_file}".format(
            path=path,
            peer_ip=peer_ip,
            module=module_name,
            secret_file=secret_file,
            exclude_cmd=exclude_cmd
        )
        try:
            LOG.debug(cmd)
            output = bash(cmd)
            if not output or output == "./":
                return True
            LOG.debug("find diff files: %s" % output)
        except:
            LOG.exception("check files diff error")

        return False

    def is_consistent(self):
        peer_data_ip = self.get_config().params.peer_data_interface_ip
        modules = self.get_config().format_modules()
        secret_file = self.get_config_item("secret_file", Lsyncd.SecretPath)
        for module in modules:
            if not self._is_same(peer_data_ip, module, secret_file):
                return False
        return True

    def sync(self):
        peer_data_ip = self.get_config().params.peer_data_interface_ip
        modules = self.get_config().format_modules()
        secret_file = self.get_config_item("secret_file", Lsyncd.SecretPath)
        for module in modules:
            exclude_cmd = self._get_exclude_args(module)
            cmd = 'rsync -avc {exclude_cmd} --delete {path}/ rsync@{peer_ip}::{module}/ --password-file {secret_file}'.format(
                path=module['source_path'],
                peer_ip=peer_data_ip,
                module=module['module'],
                secret_file=secret_file,
                exclude_cmd=exclude_cmd
            )
            LOG.debug(cmd)
            bash(cmd)
        LOG.debug("sync files success")
