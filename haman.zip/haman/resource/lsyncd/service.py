from haman.resource import ResourceService


class LsyncdService(ResourceService):
    name = "lsyncd"
