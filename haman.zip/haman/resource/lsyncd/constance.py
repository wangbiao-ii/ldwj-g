class Lsyncd:
    ConfPath = "/etc/lsyncd.conf"
    SecretPath = "/etc/rsyncd.passwd"
    DefaultSecret = "hillstone"

    DefaultLogFile = "/var/log/lsyncd/lsyncd.log"
    DefaultStatusFile = "/var/log/lsyncd/lsyncd.status"
    DefaultMaxProcess = 8
