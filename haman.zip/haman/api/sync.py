from haman.common.endpoint import RPCEndpoint
from haman.service.task import HATaskManager


class SyncEndpoint(RPCEndpoint):

    @staticmethod
    def cold_sync():
        """
        数据冷同步

        :return:
        """
        return HATaskManager().cold_sync()

    @staticmethod
    def check_consistent():
        """
        两端数据一致性检查

        :return:
        """
        return HATaskManager().check_consistent()
