from haman.api.agent import AgentEndpoint
from haman.api.ha import HAEndpoint
from haman.api.health import HealthEndpoint
from haman.api.sync import SyncEndpoint
from haman.api.system import SystemEndpoint

ENDPOINTS = [
    AgentEndpoint,
    HAEndpoint,
    HealthEndpoint,
    SyncEndpoint,
    SystemEndpoint
]


class EndpointBaseView(object):
    pass


class EndpointView(EndpointBaseView):

    def dispatch(self, data):
        for endpoint_cls in ENDPOINTS:
            obj = endpoint_cls()
            handler = getattr(obj, data['method'], None)
            if handler:
                return handler(*data['args'], **data['kwargs'])


