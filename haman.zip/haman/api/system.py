from haman.common.endpoint import RPCEndpoint
from haman.common.utils import get_all_nics_address
import logging

LOG = logging.getLogger(__name__)


class SystemEndpoint(RPCEndpoint):

    @staticmethod
    def get_networks():
        """
        查询网络信息

        :return:
        """
        return get_all_nics_address()

    @staticmethod
    def log(msg):
        LOG.debug(msg)
