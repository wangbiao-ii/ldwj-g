from haman.common.endpoint import RPCEndpoint
from haman.service.health import HealthManager


class HealthEndpoint(RPCEndpoint):

    @staticmethod
    def is_health():
        """
        资源健康检查

        :return:
        """
        return HealthManager().check()

    @staticmethod
    def get_last_health_result():
        return HealthManager().get_last_health_result()
