from haman.common.endpoint import RPCEndpoint
from haman.service.agent import AgentManager
import logging

LOG = logging.getLogger(__name__)


class AgentEndpoint(RPCEndpoint):

    @staticmethod
    def remote_agent_call(resource_name, method_name, *args, **kwargs):
        """
        远程调用agent中的方法

        :param resource_name:
        :param method_name:
        :param args:
        :param kwargs:
        :return:
        """
        agent = AgentManager().get_agent(resource_name)
        if agent:
            LOG.debug("Get remote call %s.%s, %s, %s" % (resource_name, method_name, args, kwargs))
            handler = getattr(agent, method_name)
            return handler(*args, **kwargs)
        else:
            raise Exception("Failed to find agent %s" % resource_name)
