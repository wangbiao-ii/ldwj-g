import time

from haman.common.constance import TaskStatus
from haman.common.endpoint import RPCEndpoint
from haman.common.global_value import NotifyQueue
from haman.service.state_machine import HAMAN_STATE_MACHINE
from haman.common.struct import Notify
from haman.service.task import HATaskManager
import logging

LOG = logging.getLogger(__name__)


class HAEndpoint(RPCEndpoint):

    @staticmethod
    def get_task_status():
        return HATaskManager().get_task_status()

    @staticmethod
    def build_ha(vip_list, ctl_interface, data_interface, preempt, group_id, hello_interval=3, master=True):
        """
        构建HA

        :param vip_list: 虚拟IP列表, [{"ip": x.x.x.x/y, "dev": "eth0"}]
        :param ctl_interface: HA心跳接口  {"interface": "eth1", "local_ip": "", "peer_ip":"", "netmask": ""}
        :param data_interface: HA数据接口 {"interface": "eth2", "local_ip": "", "peer_ip":"", "netmask": ""}
        :param preempt: 是否抢占, bool
        :param group_id: HA组ID，0-255
        :param hello_interval: 心跳时间间隔
        :param master: is master
        :return:
        """
        data = {
            # "peer_ip": peer_ip,
            "vip_list": vip_list,
            "ctl_interface": ctl_interface,
            "data_interface": data_interface,
            "preempt": preempt,
            "group_id": group_id,
            "hello_interval": hello_interval,
            "master": master
        }
        return HATaskManager().build_ha(data)

    def wait_ha_task(self, task_name=None, interval=3, timeout=3600):
        retry = timeout / interval
        while retry:
            result = self.get_task_status()
            if task_name:
                if result['task'] != task_name:
                    LOG.debug("Not same task...")
                    return {}

            status = result['status']
            if status == TaskStatus.Done:
                LOG.debug("HA task done")
                return result.get('result')
            elif status == TaskStatus.Doing:
                pass
            else:
                LOG.error("HA task failed")
                raise Exception("HA task failed")

            time.sleep(interval)
            retry -= 1
        else:
            raise Exception("wait HA task timeout")

    @staticmethod
    def cancel_ha(include_peer=True):
        """
        取消HA

        :return:
        """
        return HATaskManager().cancel_ha(include_peer)

    @staticmethod
    def show_ha():
        """
        查询HA详情

        :return:
        """

    @staticmethod
    def get_ha_state():
        """
        查询HA角色

        :return:
        """
        return HAMAN_STATE_MACHINE.cur_state

    @staticmethod
    def switch_ha():
        """
        切换HA状态

        :return:
        """
        return HATaskManager().manual_switch()

    @staticmethod
    def notify(state):
        """
        HA状态变更通知

        :param state:
        :return:
        """
        LOG.debug("got notify %s" % state)
        NotifyQueue.put(Notify(state))

    @staticmethod
    def follow_task(task_name, data):
        return HATaskManager().follow_task(task_name, data)
